function w3_open() {
    if(screen.height < 800){
  document.getElementById("mySidebar").style.position = "fixed";
  document.getElementById("mySidebar").style.width = "100%";
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("openNav").style.display = 'none';
}else{
  document.getElementById("main").style.marginLeft = "25%";
  document.getElementById("mySidebar").style.width = "25%";
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("openNav").style.display = 'none'; 
}
}
function w3_close() {
        if(screen.height < 800){
  document.getElementById("mySidebar").style.width = "0%";
   document.getElementById("mySidebar").style.marginLeft = "0%";
}
  document.getElementById("main").style.marginLeft = "0%";
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("openNav").style.display = "inline-block";
}