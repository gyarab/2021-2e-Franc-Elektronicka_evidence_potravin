<?php
include_once 'db.php';
if (!isset($_SESSION["jmeno"])) {
    header("Location: uvod/index.html");
    die();
}


$SQL = 'SELECT * FROM uzivatele WHERE jmeno="' . $_SESSION['jmeno'] . '";';
$result = $db_conn->query($SQL);
foreach ($result as $i) {
    $heslo = htmlspecialchars($i["heslo"]);

    if (htmlspecialchars($i["autozalohovani"]) == "1") {
        $zalohovaniauto = "checked";
    } else {
        $zalohovaniauto = "";
    }
    if (htmlspecialchars($i["autoupozornrninaexpiraci"]) == "") {
        $upozorneni = "";
        $dny = "";
    } else {
        $upozorneni = "checked";
        $dny = htmlspecialchars($i["autoupozornrninaexpiraci"]);
    }
}
?><!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
        <script type="text/javascript">
            window.OneSignal = window.OneSignal || [];
            OneSignal.push(function () {
                OneSignal.init({
                    appId: "61d1d627-baeb-466d-a0ad-571996738c2c",
                });
            });
            OneSignal.push(function () {
                /* These examples are all valid */
                OneSignal.sendTag("uzivatel", "<?php echo $_SESSION['jmeno']; ?>");
            });
        </script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/w3.css">
        <link rel="stylesheet" href="css/potraviny.css">
        <meta charset="UTF-8">
        <title>Nastavení</title>

        <style>

            .nadpis{
                top: 0px;
                position: relative;
                left: 200px;
            }
            .scrollarea{
                position: absolute;
                width: 30%;
                height: calc(100% - 180px);
                top: 180px;
                left: 130px;
                float: left;
                overflow: auto;
            }
            .položka{
                position: relative;
                background-color: #c7c7c7;
                float: top;
                display: block;
                margin: 5px;
                height: 50px;
            }
            .položka2{
                position: relative;
                top: 20px;
                background-color: #e3e3e3;
                float: top;
                display: block;
                margin: 5px;
                height: 50px;
            }
            .obnovit{
                position: relative;
                float: right;
                width: 180px;
                text-align: center;
                background-color: #8D9440;
                height: 50px;
                cursor: pointer;
                overflow: hidden;
            }
            .zelena{
                background-color: #478978;
            }
            .smazat{
                position: relative;
                float: right;
                width: 80px;
                text-align: center;
                background-color: #DD4132;
                height: 50px;
                cursor: pointer;
                overflow: hidden;
            }
            a{
                text-decoration: none;
                text-align: center;
            }
            .odkaz{
                position: absolute;
                top: 12px;
                right: 0px;
                width: 180px;
                height: 50px;
            }
            .odkaz2{
                position: absolute;
                top: 2px;
                right: 0px;
                width: 80px;
                height: 50px;
            }
            h3{
                position: absolute;
                margin: 0px;
                height: 0px;
                left: 20px;
                top: 5px;
                text-align: center;
            }
            .popup{
                position: fixed;
                width: 30%;
                height: 150px;
                left: 35%;
                top: 20%;
                background-color: #F96714;
                font-size: 20px;
                text-align: center;

            }
            #popup{
                visibility: hidden;
            }
            #popup2{
                visibility: hidden;
            }
            .tlačítka{
                position: relative;
                top: 30px;
                width: 200px;
            }
            .textpole{
                position: relative;
                height: 40px;
                top: 5px;
                width: 250px;
                left: 150px;
                border: none;

            }
            .switch {
                position: relative;
                display: inline-block;
                width: 60px;
                height: 34px;
                top: 10px;
                float: right;
                right: 10px;
            }

            /* Hide default HTML checkbox */
            .switch input {
                opacity: 0;
                width: 0;
                height: 0;
            }

            /* The slider */
            .slider {
                position: absolute;
                cursor: pointer;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: #ccc;
                -webkit-transition: .4s;
                transition: .4s;
            }

            .slider:before {
                position: absolute;
                content: "";
                height: 26px;
                width: 26px;
                left: 4px;
                bottom: 4px;
                background-color: white;
                -webkit-transition: .4s;
                transition: .4s;
            }

            input:checked + .slider {
                background-color: #2196F3;
            }

            input:focus + .slider {
                box-shadow: 0 0 1px #2196F3;
            }

            input:checked + .slider:before {
                -webkit-transform: translateX(26px);
                -ms-transform: translateX(26px);
                transform: translateX(26px);
            }

            /* Rounded sliders */
            .slider.round {
                border-radius: 34px;
            }

            .slider.round:before {
                border-radius: 50%;
            }
            .kdyprojde{
                left:480px; width: 100px;
            }
            .dní{
                position: relative;
                width: 30px;
                top: -35px;
                left: 590px
            }
            .kategorie{
                height: 300px;
                overflow: auto;
            }
            .novakategorie{
                position: relative;
                width: 45%;
                left: 20px;
            }
            .novakategorieikonka{
                position: relative;
                width: 45%;
                left: 20px;
            }
            .pridatkategorii{
                top:-35px;height: 40px;
            }
            .nahled{
                height: 50px;
            }
            .trochudolu{
                position: absolute;
                top: 12px;
                width: 100%;
                height: 100%;
            }
            @media only screen and (max-width: 1000px) {
                .nadpis{
                    top: 0px;
                    position: relative;
                    left: 50px;
                    width: 300px;
                }
                .scrollarea{
                    width: 100%;
                    left: 0px;
                    right: 0px;
                    top: 10px;
                }
                .popup{
                    width: 90%;
                    height: 180px;
                    left: 5%;   
                }
                .tlačítka{
                    position: relative;
                    top: 30px;
                    width: 45%;
                }
                .textpole{
                    left: 0px;
                    position: absolute;
                    width: 100%;
                }
                h3{
                    position: relative;
                    text-align: left;
                }
                .větší{
                    height: 80px;
                }
                .kdyprojde{
                    position: relative;
                    float: right;
                    left: -60px;
                    top: 40px;
                    width: 100px;
                }
                .dní{
                    position: relative;
                    top: 40px;
                    float: right;
                    left: 55px;
                    width: 0px;
                }
                .novakategorieikonka{
                    top: 50px;
                }
                .pridatkategorii{
                    top: 50px;
                    width: 100%;
                }
            }
            .pointer{
                cursor: pointer;
            }
            h2{
                font-size: 28px;
                margin-bottom: 0px;
            }
            .odpoved{
                position: relative;
                margin-top: 0px;
                font-size: 28px;
                font-family: "Segoe UI",Arial,sans-serif;
                background-color: white;
                padding-left: 20px;
                border-radius: 3px;
            }
        </style>
    </head>
    <body style="background-color:#F9EDDC;">

        <div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="mySidebar">
            <button class="w3-bar-item w3-button w3-large"
                    onclick="w3_close()">Zavřít &times;</button>
            <center><div class="prihlasovani" ></div><p><?php echo $_SESSION["jmeno"]; ?></p><a class="odhlasit" href="logout.php">odhlásit se</a><br></center>
            <a href="index.php?mode=zakladni" class="w3-bar-item w3-button">Domů</a>
            <center><p>Filtrovat</p> </center>  <hr /> 
            <a href="index.php?mode=jmeno" class="w3-bar-item w3-button">Podle názvu</a>
            <a href="index.php?mode=kategorie" class="w3-bar-item w3-button">podle kategorie</a>
            <a href="hledatdatum.php" class="w3-bar-item w3-button">datum spotřeby</a>

            <center><p>Správa dat</p> </center>  <hr /> 
            <a href="zalohovani.php" class="w3-bar-item w3-button">Zálohování</a>
            <a href="import.php" class="w3-bar-item w3-button">Import</a>
            <a href="export.php" class="w3-bar-item w3-button">Export</a>

            <center><p>Správa databáze</p> </center>  <hr /> 
            <a href="ulozenepotraviny.php" class="w3-bar-item w3-button">Uložené potraviny</a>
            <a href="stalepotraviny.php" class="w3-bar-item w3-button">Stálé potraviny</a>
            <a href="nastaveni.php" class="w3-bar-item w3-button">nastavení</a>
        </div>

        <div id="main" >

            <div class="w3-teal" >

                <button id="openNav" class="w3-button w3-teal w3-xlarge" onclick="w3_open()">&#9776;</button>
                <div class="w3-container">

                    <h1 class="nadpis">Nastavení</h1>

                </div>

            </div>  
            <div class="scrollarea">
                <h1>Můj účet</h1>
                <h2>Uživatelské jméno</h2>
                <p class="odpoved"><?php echo $_SESSION["jmeno"]; ?></p>
                <h2>Email</h2>
                <p class="odpoved"><?php echo $_SESSION["jmeno"]; ?></p>
                <a onclick="ulozit();" class="položka zelena"><div class=" pointer" style="color: white;"><h3>Uložit změny</h3></div></a>
                <br><br>
                <div class="položka"><h3>Heslo:</h3><input id="heslo2" class="textpole" type="password" value="<?php echo $heslo; ?>"><div class="obnovit"><a onclick="redirect('noveheslo')" class="odkaz" >Nastavit nové heslo</a></div><div class="smazat"><a onclick="redirect('zobrazheslo')" class="odkaz2" >Zobrazit heslo</a></div></div>
                <div class="položka"><h3>Automatické zálohování:</h3><label class="switch"><input id="checkbox" <?php echo $zalohovaniauto; ?> type="checkbox"><span class="slider"></span></label></div>
                <div class="položka"><div class='onesignal-customlink-container'></div></div>
                <div class="položka větší"><h3>Zapnout upozornění na procházející potraviny:</h3><label class="switch"><input id="upozorneni" <?php echo $upozorneni; ?> type="checkbox"><span class="slider"></span></label></div>
                <div class="položka větší"><h3>Upozornit na potraviny, které projdou do:</h3><input id="kdyprojde" class="textpole kdyprojde" type="number" value="<?php echo $dny; ?>"><h3 class="dní">dní</h3></div>

                <div class="položka kategorie"><h3 >Kategorie</h3><br><br><input id="nazevnovekategorie" class="textpole novakategorie" type="text" placeholder="Název nové kategorie"><input id="ikonkanovakategorie" class="textpole novakategorieikonka" type="text" placeholder="Odkaz na ikonku"><div class="obnovit pridatkategorii"><a onclick="pridatkategorii()" class="odkaz" style="top:6px;">Přidat kategorii</a></div>
                    <br> <br> <br>
                    <?php
                    $SQL = 'SELECT * FROM ' . $_SESSION['jmeno'] . ' WHERE typ="kategorie";';
                    $result = $db_conn->query($SQL);
                    foreach ($result as $i) {

                        $jmeno = htmlspecialchars($i["jmeno"]);

                        echo '<div class="položka2"><img class="nahled" src="' . htmlspecialchars($i["poznamky"]) . '"><h3 style="position:absolute;left:50px;">' . $jmeno . '</h3><div class="smazat"><a onclick="prycskategorii(' . "'" . htmlspecialchars($i["id"]) . "'" . ')" class="odkaz2 trochudolu" >X</a></div></div>';
                    }
                    ?>
                </div>


            </div>
        </div>
        <div id="popup" class="popup"><p id="text"></p><button class="tlačítka" onclick="smazat()">Ne</button><button class="tlačítka" onclick="potvrzeno()" id="ano">ano</button></div>
        <p hidden id="url"></p><p hidden id="prikaz"></p><p hidden id="idkategorie"></p>
        <div id="popup2" class="popup"><p id="text2"></p><button class="tlačítka" onclick="nesmazatkategorii()">Ne</button><button class="tlačítka" onclick="smazatkategorii()" id="ano">ano</button></div>

        <script src="jquery-3.3.1.min.js"></script>
        <script src="menu.js"></script>
        <script type="text/javascript">
            function redirect(prikaz) {

                if (prikaz === "zobrazheslo") {
                    if (document.getElementById("heslo2").type === "password") {
                        document.getElementById("heslo2").type = "text";
                    } else {
                        document.getElementById("heslo2").type = "password";
                    }
                }
                if (prikaz === "noveheslo") {
                    document.getElementById("popup").style.visibility = "visible";
                    document.getElementById("text").innerHTML = "Opravdu chtete změnit heslo?";
                }
            }
            function smazat() {
                document.getElementById("popup").style.visibility = "hidden";
            }
            function potvrzeno() {
                var heslo = document.getElementById("heslo2").value;
                window.location.replace("NastaveniFunctionality.php?heslo=" + heslo);
            }
            function ulozit() {
                var zalohovani = document.getElementById("checkbox").checked;
                var upozorneni = document.getElementById("upozorneni").checked;
                var kdyprojde = document.getElementById("kdyprojde").value;
                if (kdyprojde === "") {
                    kdyprojde = 0;
                }
                window.location.replace("NastaveniFunctionality.php?zalohovani=" + zalohovani + "&upozorneni=" + upozorneni + "&kdyprojde=" + kdyprojde);
            }
            function pridatkategorii() {
                var jmeno = document.getElementById("nazevnovekategorie").value;
                var ikonka = document.getElementById("ikonkanovakategorie").value;
                if (jmeno === "") {
                    alert("Musí být vyplněno jméno.")
                    return;
                }
                if (ikonka === "") {
                    alert("Musí být vyplněn odkaz na ikonku. Ten získáte když na libovolný obrázek na internetu kliknete pravým tlačítkem a vyberete možnost Kopírovat adresu obrázku.")
                    return;
                }
                window.location.replace("NastaveniFunctionality.php?pridatkategorii=" + jmeno + "&ikonka=" + ikonka);
            }
            function prycskategorii(id) {
                document.getElementById("idkategorie").innerHTML = id;
                document.getElementById("popup2").style.visibility = "visible";
                document.getElementById("text2").innerHTML = "Opravdu chtete kategorii odstranit?";
            }
            function smazatkategorii() {
                var id = document.getElementById("idkategorie").textContent;
                window.location.replace("NastaveniFunctionality.php?odstranitkategorii=" + id);
            }
            function nesmazatkategorii() {
                document.getElementById("popup2").style.visibility = "hidden";
            }
        </script>




    </body>
</body>
</html>
