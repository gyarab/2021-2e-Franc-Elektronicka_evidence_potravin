<?php 
include_once 'db.php';
if(!isset($_SESSION["jmeno"])){
    header("Location: uvod/index.html");
    die();
}

?><!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/w3.css">
        <meta charset="UTF-8">
        <title></title>
        <style>
            
            .nadpis{
                top: 0px;
                position: relative;
                left: 200px;
            }
            .input{
                position: relative;
                top: -70px; 
                border: none;
                border-radius: 4px;
            }
            .listatlacitko{
                position: relative;
                top: -70px;
                border: none;
                border-radius: 4px;
                height: 50px;
                width: 60px;
                left: 540px;
                background-image: url("lupa.png");
                background-size: 50px;
                background-position-x: 5px;
            }
            #vyhledatpodleeanu{
                margin: 0px;
                width: 400px;
                height: 50px;
                left: 600px;
            }
            p{
                font-family: arial;
                font-size: 20px;
            }
            .seznam{
    position: relative;
    text-align: center;
    top: 20px;
    left: 2px;
    overflow: auto;
}
            

.potravina{
    position: relative;
    display: block;
    width: 160px;
    height: 196px;
    margin: 2.5px;
    background-color: #999999;
}
.potravinatext{
    top: 10px;
    position: relative;
    font-family: arial;
    font-size: 15px;
    text-align: center;
    text-decoration: none;
    margin: 0px;
    width: 120px;
    height: 40px;
}
a{
     position: relative;
    text-decoration: none;
    margin: 0px;
    float: left;
}
.krizek{
    position: absolute;
    
                top: 2.5px;
                right: 2.5px;
                background-image: url("krizek.png");
                background-size: 15px;
                width: 15px;
                height: 15px;
                background-color: transparent;
                
            }
            .vratit{
                position: absolute;
                top: 0px;
                right: 0px;
                width: 500px;
                height: 50px;
                background: #cccccc;
                animation: priletnuti 1s ;
                transition: right 1s;
            }
            @keyframes priletnuti {
    from {right: -600px;}
    to {right: 0px;}
    
}
.pridatsean{
        position: relative;
        width: 70px;
        height: 70px;
        left: 25px;
        top: 10px;
        background-image: url("scanner.png");
        background-size: 70px;
        
    }
    .pridatbezean{
        position: relative;
        width: 70px;
        height: 70px;
        left: 25px;
        top: 15px;
        background-image: url("vytvor ean.png");
        background-size: 70px;
        
    }
                @media only screen and (max-width: 1000px) {
                #vyhledatpodleeanu{
                    left: 10px;
                    height: 50px;
                    width: 80%;
                }
                .nadpis{
               left: 20px;
            }
                form{
                    height: 0px;
                    position: relative;
                }
                .listatlacitko{
                     left: 5px;
                     top: -70px;
                }
                
                .seznam{
    position: relative;
    top: 2px;
    left: 2px;
    overflow: auto;

}
.vratit{
                position: absolute;
                top: 0px;
                right: 0px;
                width: 70%;
                height: 50px;
                background: #cccccc;
                animation: priletnuti 1s ;
                transition: right 1s;
            }
}
.ikonka{
    position: relative;
    width: 70px;
    left: 28px;
    top: 10px;
}
.import{
    position: relative;
    top: 150px;
    
}
        </style>
    </head>
    <body style="background-color:#cccccc;">


<div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="mySidebar">
  <button class="w3-bar-item w3-button w3-large"
  onclick="w3_close()">Zavřít &times;</button>
<a href="index.php" class="w3-bar-item w3-button">Domů</a>
  <center><p>Filtrovat</p> </center>  <hr /> 
      
            <a href="hledatjmeno.php" class="w3-bar-item w3-button">Podle názvu</a>
  <a href="hledatkategorii.php" class="w3-bar-item w3-button">podle kategorie</a>
  <a href="hledatdatum.php" class="w3-bar-item w3-button">datum spotřeby</a>
  
  <center><p>Správa dat</p> </center>  <hr /> 
  
  <a href="zalohovani.php" class="w3-bar-item w3-button">Zálohování</a>
  <a href="import.php" class="w3-bar-item w3-button">Import</a>
  <a href="export.php" class="w3-bar-item w3-button">Export</a>
  <center><p>Správa databáze</p> </center>  <hr /> 
  
  <a href="ulozenepotraviny.php" class="w3-bar-item w3-button">Uložené potraviny</a>
  <a href="stalepotraviny.php" class="w3-bar-item w3-button">Stálé potraviny</a>
  <a href="nastaveni.php" class="w3-bar-item w3-button">nastavení</a>
</div>

        <div id="main" >

<div class="w3-teal" >
     
  <button id="openNav" class="w3-button w3-teal w3-xlarge" onclick="w3_open()">&#9776;</button>
  <div class="w3-container">
      
      <h1 class="nadpis">Import</h1>
      
  </div>
  
</div>  <center><div class="import">

        <form action="" method="post" enctype="multipart/form-data">
            <p>Vyberte soubor k nahrání</p>
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Nahrát" name="submit">
</form>
    <?php
    if(isset($_POST["submit"])) {
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));



// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000000) {
    echo "Soubor musí být menší než 5 Mb. ";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "eep") {
    echo "Je možné importovat pouze .eep soubory. ";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Při nahrávání nastala chyba. ";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
            //---------------------    nahrávání    ------------------------------
        
            $file = explode("{",file_get_contents("uploads/".basename( $_FILES["fileToUpload"]["name"])));
            for($i=0;$i<count($file);$i++){
                $part = explode("}", $file[$i]);
                $SQL = "INSERT INTO ".$_SESSION["jmeno"]." (typ,ean,jmeno,kategorie,spotreba,mnozstvi,jednotky) VALUES ('potraviny','".$part[0]."','".$part[1]."','".$part[2]."','".$part[3]."','".$part[4]."','".$part[5]."');";
                $result = $db_conn->query($SQL);
            }
            echo '<script>window.location.replace("index.php");</script>';
        
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
    }
?>
</div>
   </center>
</div>

  <?php
            if(isset($_GET['smazane'])){
                echo '<center><a href="vratitPotravinu.php?vracenapotravina='.$_GET['smazane'].'" id="vratit" class="vratit" onclick="zmiz();">Vrátit smazanou potravinu</a></center>';
            }
        ?>      
        
<script src="menu.js"></script>
<script src="jquery-3.3.1.min.js"></script>
<script type="text/javascript">
                setTimeout(function(){    
                 $('.vratit').animate({right: '-600px'},"slow");

                    alert("funguje to");
                }, 3000);
                
                
            
                </script>


</body>
    </body>
</html>
