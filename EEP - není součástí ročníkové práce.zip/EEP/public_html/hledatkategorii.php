<?php 

include_once 'db.php';
include 'funkce.php';

if(isset($_POST['kategorie'])){
    $kategorie = $_POST['kategorie'];
}

/*
CREATE TABLE `wwp`.`admin` ( `typ` VARCHAR(100) NOT NULL , `id` INT NOT NULL AUTO_INCREMENT , `ean` VARCHAR(500) NOT NULL , `jmeno` VARCHAR(200) NOT NULL , `kategorie` VARCHAR(100) NOT NULL , `spotreba` VARCHAR(100) NOT NULL , `mnozstvi` VARCHAR(100) NOT NULL , `jednotky` VARCHAR(100) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
 */
?><!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/w3.css">
<link rel="stylesheet" href="css/potraviny.css">
        <meta charset="UTF-8">
        <title></title>
        <style>
            
            .nadpis{
                top: 0px;
                position: relative;
                left: 200px;
            }
        </style>
    </head>
    <body style="background-color:#cccccc;">


        <div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="mySidebar">
  <button class="w3-bar-item w3-button w3-large"
  onclick="w3_close()">Zavřít &times;</button>
<a href="index.php" class="w3-bar-item w3-button">Domů</a>
  <center><p>Filtrovat</p> </center>  <hr /> 
      
            <a href="hledatjmeno.php" class="w3-bar-item w3-button">Podle názvu</a>
  <a href="hledatkategorii.php" class="w3-bar-item w3-button">podle kategorie</a>
  <a href="hledatdatum.php" class="w3-bar-item w3-button">datum spotřeby</a>
  
  <center><p>Správa dat</p> </center>  <hr /> 
  
  <a href="zalohovani.php" class="w3-bar-item w3-button">Zálohování</a>
  <a href="import.php" class="w3-bar-item w3-button">Import</a>
  <a href="export.php" class="w3-bar-item w3-button">Export</a>
  <center><p>Správa databáze</p> </center>  <hr /> 
  
  <a href="ulozenepotraviny.php" class="w3-bar-item w3-button">Uložené potraviny</a>
  <a href="stalepotraviny.php" class="w3-bar-item w3-button">Stálé potraviny</a>
  <a href="nastaveni.php" class="w3-bar-item w3-button">nastavení</a>
</div>

        <div id="main" >

<div class="w3-teal" >
  <button id="openNav" class="w3-button w3-teal w3-xlarge" onclick="w3_open()">&#9776;</button>
  <div class="w3-container">
      
      <h1 class="nadpis">Domácí sklad</h1>
      
  </div>

</div>  <form action="" method="post"><select class="input" id="vyhledatpodleeanu" name="kategorie">
                <?php
                if(!isset($kategorie)){
                    $SQL = 'SELECT * FROM '.$_SESSION['jmeno'].' WHERE typ="kategorie" ORDER BY jmeno;';
                    $result = $db_conn->query($SQL);
                    foreach ($result as $i){
                        if(!isset($kategorie)){
                            $kategorie = htmlspecialchars($i["jmeno"]);
                        }
                    echo "<option>".htmlspecialchars($i["jmeno"])."</option>";
                    }
                }else{
                echo "<option>".$kategorie."</option>"; 
                $SQL = 'SELECT * FROM '.$_SESSION['jmeno'].' WHERE typ="kategorie" ORDER BY jmeno;';
                $result = $db_conn->query($SQL);
                    foreach ($result as $i){
                        if($kategorie !== htmlspecialchars($i["jmeno"])){
                            echo "<option>".htmlspecialchars($i["jmeno"])."</option>";
                        }
                    }
                }
                ?>
                
            </select><input type="submit" class="listatlacitko" value=" "></form>
<div class="seznam">
    <div  class="potravina"><a href="ean.php" class="pridatsean"></a><a href="vygenerovatEan.php" class="pridatbezean"></a></div>
    <?php
    if(isset($kategorie)){
    $SQL = 'SELECT * FROM '.$_SESSION['jmeno'].' WHERE typ="potraviny" AND kategorie="'.$kategorie.'";';
    $result = $db_conn->query($SQL);
    if($result->rowCount() === 0){
        echo '<p>V kategorii: "'.$kategorie.'" nejsou nalezeny žádné potraviny</p>';
    }
    foreach ($result as $i){
        echo '<div  class="potravina">';
        
        if(htmlspecialchars($i["mnozstvi"])== NULL){
            $mnoz = NULL;
        }else{
            if(htmlspecialchars($i["mnozstvi"]) == 1){
                $mnoz = NULL;
            }else{
                $mnoz = "<br />(".htmlspecialchars($i["mnozstvi"])." ".htmlspecialchars($i["jednotky"]).")";
            }
        }
          
        echo kategorie($db_conn,htmlspecialchars($i["kategorie"]));
        
        $jmeno = "";
        $pole = explode(" ", htmlspecialchars($i["jmeno"]));
        for($j=0;$j<count($pole);$j++){
            if($j < 2){
            if(strlen($pole[$j]) > 10){
                $jmeno = $jmeno.substr($pole[$j],10)."...<br />";
            } else {
                $jmeno = $jmeno." ".$pole[$j];
            }   
            }
        }

        echo '<a href="smazatPotravinu.php?id='.htmlspecialchars($i["id"]).'" class="krizek"></a><a onclick="upravit('.htmlspecialchars($i["id"]).')" class="potravinatext">'. $jmeno.$mnoz.'</a>';
        if(htmlspecialchars($i["spotreba"]) != "..20"){
        echo '<a class="potravinatext">'. htmlspecialchars($i["spotreba"]).'</a>';
        }
        echo '</div>';
        
         
    }
    }else{
        echo '<p>Nemáte vytvořenou žádnou kategorii. Vytvořit ji můžete v nastavení.</p>';
    }
    ?>
    
</div>
   
</div>

  <?php
            if(isset($_GET['smazane'])){
                echo '<center><a href="vratitPotravinu.php?vracenapotravina='.$_GET['smazane'].'" id="vratit" class="vratit" onclick="zmiz();">Vrátit smazanou potravinu</a></center>';
            }
        ?>      
        
<script src="menu.js"></script>
<script src="jquery-3.3.1.min.js"></script>
    <div class="uprava" id="uprava"><div class="krizek" onclick="zavritupravovani()"></div><iframe id="iframe"src=""></iframe></div>
        <script type="text/javascript">
        document.getElementById("uprava").style.display = 'none'; 
        function upravit(id){
        document.getElementById("iframe").src = 'upravit.php?id='+id; 
        document.getElementById("uprava").style.display = 'inline-block'; 
        }
        function zavritupravovani(){
            document.getElementById("uprava").style.display = 'none'; 
        }
        window.addEventListener("message", receiveMessage, false);
        function receiveMessage(event) {
         if (event.data === "zavrit"){
             document.getElementById("uprava").style.display = 'none'; 
             location.reload();
         }
 
      return;
}
</script>
</body>
    </body>
</html>
