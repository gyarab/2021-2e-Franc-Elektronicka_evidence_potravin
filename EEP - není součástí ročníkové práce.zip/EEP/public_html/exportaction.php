<?php
include_once 'db.php';
if(isset($_GET['eep'])){
    $obsah = "";
    $SQL = 'SELECT * FROM '.$_SESSION["jmeno"].' WHERE typ="potraviny";';
    $result = $db_conn->query($SQL);
    foreach ($result as $i){
        if($obsah==""){
            $obsah=htmlspecialchars($i["ean"])."}".htmlspecialchars($i["jmeno"])."}".htmlspecialchars($i["kategorie"])."}".htmlspecialchars($i["spotreba"])."}".htmlspecialchars($i["mnozstvi"])."}".htmlspecialchars($i["jednotky"]);
        }else{
        $obsah= $obsah."{".htmlspecialchars($i["ean"])."}".htmlspecialchars($i["jmeno"])."}".htmlspecialchars($i["kategorie"])."}".htmlspecialchars($i["spotreba"])."}".htmlspecialchars($i["mnozstvi"])."}".htmlspecialchars($i["jednotky"]);
        }
    }
$myfile = fopen("export.eep", "w") or die("Unable to open file!");
$txt = $obsah;
fwrite($myfile, $txt);
fclose($myfile);
     $filepath = "export.eep";
    
    // Process download
    if(file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($filepath).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filepath));
        flush(); // Flush system output buffer
        readfile($filepath);
        exit;
    }
}elseif(isset($_GET['excel'])){
include_once 'PHPExcel-1.8/Classes/PHPExcel.php';
$excel = new PHPExcel(); //vytvoříme novou třídu
$list = $excel->getActiveSheet(); //získáme aktivní list
$list->setTitle("Export"); //nastavíme titulek listu

$list->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE); //orientace stránky na šířku
$list->getColumnDimension("A")->setWidth(5);
$list->getColumnDimension("M")->setWidth(5);

$alstyle = $list->mergeCells("B2:G1")->setCellValue("A1","Eelktronická evidence potravin",false)->getStyle("B2");
$alstyle->getFont()->setBold(true)->setSize(12); //tučný text velikosti 12
$alstyle->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB("cccccc"); //vyplníme šedou barvou #cccccc
$alstyle->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); //zarovnání na střed

// sloučíme buňky A1 až L1, nastavíme obsah a získáme její styly


$list->setCellValue("E5","Zpracoval:"); //nastavíme hodnotu buňky E5
$list->setCellValueByColumnAndRow(12,7,"Zaplaceno vše"); //nastavíme hodnotu pro 12 sloupec a 7 řádek (nemusíme znát písmenka sloupců)

//Při zadávání funkcí musíme používat její anglické názvy
$list->setCellValue("C5","=SUM(L8:L25)");

//nastavíme tenké ohraničení buněk
$list->getStyle('A7:L25')->getBorders()->getAllBorders()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

// mezi buňkami A7 až L7 dolní ohraničení bude dvojité
$list->getStyle('A7:L7')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_DOUBLE);

$format = "xlsx"; // "xls" pro starý formát
if($format == "xlsx"){
  header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
}else{ //xls
  header('Content-Type: application/vnd.ms-excel');
}        
header('Content-Disposition: attachment;filename="export.'.$format.'"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($excel, ($format == "xlsx" ? "Excel2007" : "Excel5"));
$objWriter->save('php://output'); //stahování souboru
}elseif(isset($_GET['txt'])){
    $obsah = "";
    $SQL = 'SELECT * FROM '.$_SESSION["jmeno"].' WHERE typ="potraviny";';
    $result = $db_conn->query($SQL);
    foreach ($result as $i){
        if($obsah==""){
            $obsah=htmlspecialchars($i["jmeno"])."\t\t\t".htmlspecialchars($i["kategorie"])."\t\t".htmlspecialchars($i["spotreba"])."\t".htmlspecialchars($i["mnozstvi"])." ".htmlspecialchars($i["jednotky"]);
        }else{
        $obsah= $obsah."\n".htmlspecialchars($i["jmeno"])."\t\t\t".htmlspecialchars($i["kategorie"])."\t\t".htmlspecialchars($i["spotreba"])."\t".htmlspecialchars($i["mnozstvi"])." ".htmlspecialchars($i["jednotky"]);
        }
    }
$myfile = fopen("export.txt", "w") or die("Unable to open file!");
$txt = $obsah;
fwrite($myfile, $txt);
fclose($myfile);
  $filepath = "export.txt";
    
    // Process download
    if(file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($filepath).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filepath));
        flush(); // Flush system output buffer
        readfile($filepath);
        exit;
    }
}