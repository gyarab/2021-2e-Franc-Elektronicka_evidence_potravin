<?php 

include_once 'db.php';
include 'funkce.php';

if(!isset($_POST['datum']) or $_POST['datum'] == NULL){
     $zobraz = NULL;
     $datum = 7;
} else {
    $datum = $_POST['datum'];
    $zobraz =$_POST['datum'];
    
}

if(isset($_GET['jmeno'])){
    $_SESSION['jmeno'] = $_GET['jmeno'];
    $_SESSION['heslo'] = $_GET['heslo'];
    $datum = $_GET['dny'];
    $zobraz = $_GET['dny'];
}else{
if(!isset($_SESSION["jmeno"])){
    header("Location: uvod/index.html");
    die();
}
}
/*
CREATE TABLE `wwp`.`admin` ( `typ` VARCHAR(100) NOT NULL , `id` INT NOT NULL AUTO_INCREMENT , `ean` VARCHAR(500) NOT NULL , `jmeno` VARCHAR(200) NOT NULL , `kategorie` VARCHAR(100) NOT NULL , `spotreba` VARCHAR(100) NOT NULL , `mnozstvi` VARCHAR(100) NOT NULL , `jednotky` VARCHAR(100) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
 */
?><!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/w3.css">
<link rel="stylesheet" href="css/potraviny.css">
        <meta charset="UTF-8">
        <title></title>
        <style>
            
            .nadpis{
                top: 0px;
                position: relative;
                left: 200px;
            }
        </style>
    </head>
    <body style="background-color:#cccccc;">


        <div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="mySidebar">
  <button class="w3-bar-item w3-button w3-large"
  onclick="w3_close()">Zavřít &times;</button>
            
            <a href="index.php" class="w3-bar-item w3-button">Domů</a>
  <center><p>Filtrovat</p> </center>  <hr /> 
      
            <a href="hledatjmeno.php" class="w3-bar-item w3-button">Podle názvu</a>
  <a href="hledatkategorii.php" class="w3-bar-item w3-button">podle kategorie</a>
  <a href="hledatdatum.php" class="w3-bar-item w3-button">datum spotřeby</a>
  
  <center><p>Správa dat</p> </center>  <hr /> 
  
  <a href="zalohovani.php" class="w3-bar-item w3-button">Zálohování</a>
  <a href="import.php" class="w3-bar-item w3-button">Import</a>
  <a href="export.php" class="w3-bar-item w3-button">Export</a>
  <center><p>Správa databáze</p> </center>  <hr /> 
  
  <a href="ulozenepotraviny.php" class="w3-bar-item w3-button">Uložené potraviny</a>
  <a href="stalepotraviny.php" class="w3-bar-item w3-button">Stálé potraviny</a>
  <a href="nastaveni.php" class="w3-bar-item w3-button">nastavení</a>
</div>

        <div id="main" >

<div class="w3-teal" >
  <button id="openNav" class="w3-button w3-teal w3-xlarge" onclick="w3_open()">&#9776;</button>
  <div class="w3-container">
      
      <h1 class="nadpis">Domácí sklad</h1>
      
  </div>

</div>  <form action="" method="post"><input type="text" class="input" id="vyhledatpodleeanu" name="datum" value="<?php echo $zobraz; ?>" placeholder="Oranžově označit potraviny, které projdou do: 7 dní" autofocus><input type="submit" class="listatlacitko" value=" "></form>

<div class="seznam">
    <div  class="potravina"><a href="ean.php" class="pridatsean"></a><a href="vygenerovatEan.php" class="pridatbezean"></a></div>
    <?php
    
    $SQL = 'SELECT * FROM '.$_SESSION['jmeno'].' WHERE typ="potraviny";';
    $result = $db_conn->query($SQL);
    $pole = array(NULL);
    $id = array(NULL);
    foreach ($result as $i){
        if(htmlspecialchars($i["spotreba"])!= ""){
        $cele = explode(".",htmlspecialchars($i["spotreba"]));
                  $d1 = $cele[0];
                  if($cele[0]<10){
                      $d1 = "0".$cele[0];
                  }
                  $d2 = $cele[1];
                  if($cele[1]<10){
                      $d2 = "0".$cele[1];
                  }
                  $d3 = $cele[2];
        array_push($pole, $d3. $d2. $d1);
        array_push($id,htmlspecialchars($i['id']) );
        }
    }
        $vetsi = 0;
        $mensi = 0;
        $vetsi2 = 0;
        $mensi2 = 0;
    for($i = 0;$i<sizeof($pole);$i++){
        for($j = 0;$j<sizeof($pole);$j++){
            
                $x = $pole[$i];
                $y = $pole[$j];
                $x2 = $id[$i];
                $y2 = $id[$j];
                    if ($x < $y) {
                        
                        $vetsi = $y;
                        $mensi = $x;
                        $vetsi2 = $y2;
                        $mensi2 = $x2;
                    } else {
                        $vetsi = $x;
                        $mensi = $y;
                        $vetsi2 = $x2;
                        $mensi2 = $y2;
                    }
                $pole[$i] = $vetsi;
                $pole[$j] = $mensi;
                $id[$i] = $vetsi2;
                $id[$j] = $mensi2;
        }
    }
    foreach ($id as $j){
    $SQL = 'SELECT * FROM '.$_SESSION['jmeno'].' WHERE id="'. htmlspecialchars($j).'" AND typ="potraviny";';
    $result = $db_conn->query($SQL);
    
    foreach ($result as $i){
        $cele = explode(".",htmlspecialchars($i["spotreba"]));
                  $d1 = $cele[0];
                  if($cele[0]<10){
                      $d1 = "0".$cele[0];
                  }
                  $d2 = $cele[1];
                  if($cele[1]<10){
                      $d2 = "0".$cele[1];
                  }
                  $d3 = $cele[2];
                  $cele = $d3.$d2.$d1;
        $barva = NULL;

        $date = new DateTime(date("Y-m-d"));
        $interval = new DateInterval("P".$datum."D");
        $date->add($interval);

        if($cele < $date->format("Ymd")){
            $barva = "background-color: orange;";
        }
        if($cele < date("Ymd")){
            $barva = "background-color: red;";
        }
        echo '<div  class="potravina" style="'.$barva.'">';
        
        if(htmlspecialchars($i["mnozstvi"])== NULL){
            $mnoz = NULL;
        }else{
            if(htmlspecialchars($i["mnozstvi"]) == 1){
                $mnoz = NULL;
            }else{
                $mnoz = "<br />(".htmlspecialchars($i["mnozstvi"])." ".htmlspecialchars($i["jednotky"]).")";
            }
        }
        
        echo kategorie($db_conn,htmlspecialchars($i["kategorie"]));
        $jmeno = "";
        $pole = explode(" ", htmlspecialchars($i["jmeno"]));
        for($j=0;$j<count($pole);$j++){
            if($j < 2){
            if(strlen($pole[$j]) > 10){
                $jmeno = $jmeno.substr($pole[$j],10)."...<br />";
            } else {
                $jmeno = $jmeno." ".$pole[$j];
            }   
            }
        }

        echo '<a href="smazatPotravinu.php?id='.htmlspecialchars($i["id"]).'" class="krizek"></a><a onclick="upravit('.htmlspecialchars($i["id"]).')" class="potravinatext">'. $jmeno.$mnoz.'</a>';
        if(htmlspecialchars($i["spotreba"]) != "..20"){
        echo '<a class="potravinatext">'. htmlspecialchars($i["spotreba"]).'</a>';
        }
        echo '</div>';
        
         
    }
    }
    ?>
    
</div>
   
</div>

  <?php
            if(isset($_GET['smazane'])){
                echo '<center><a href="vratitPotravinu.php?vracenapotravina='.$_GET['smazane'].'" id="vratit" class="vratit" onclick="zmiz();">Vrátit smazanou potravinu</a></center>';
            }
        ?>      
        
<script src="menu.js"></script>
<script src="jquery-3.3.1.min.js"></script>
    <div class="uprava" id="uprava"><div class="krizek" onclick="zavritupravovani()"></div><iframe id="iframe"src=""></iframe></div>
        <script type="text/javascript">
        document.getElementById("uprava").style.display = 'none'; 
        function upravit(id){
        document.getElementById("iframe").src = 'upravit.php?id='+id; 
        document.getElementById("uprava").style.display = 'inline-block'; 
        }
        function zavritupravovani(){
            document.getElementById("uprava").style.display = 'none'; 
        }
        window.addEventListener("message", receiveMessage, false);
        function receiveMessage(event) {
         if (event.data === "zavrit"){
             document.getElementById("uprava").style.display = 'none'; 
             location.reload();
         }
 
      return;
}
</script>
</body>
    </body>
</html>
