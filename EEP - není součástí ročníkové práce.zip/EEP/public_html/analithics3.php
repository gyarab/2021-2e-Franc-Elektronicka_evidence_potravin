<html>
  <head>
    <script type="text/javascript" src="js/graf.js"></script>
    
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
            ['cas', 'ovoce', 'zelenina', 'maso', 'konzervy', 'mléčné výrobky', 'sypké suroviny', 'tekuté suroviny', 'domací produkty', 'vody', 'sladkosti'],
            <?php 
            include_once 'db.php';
            $SQL = 'SELECT * FROM analithics;';
    $result = $db_conn->query($SQL);
    foreach ($result as $i){
        
        echo "['". htmlspecialchars($i['cas'])."',". htmlspecialchars($i['ovoce']).",". htmlspecialchars($i['zelenina']).",". htmlspecialchars($i['maso']).",". htmlspecialchars($i['konzervy']).",". htmlspecialchars($i['mlecnebyrobky']).",". htmlspecialchars($i['sypkesuroviny']).",". htmlspecialchars($i['tekutesuroviny']).",". htmlspecialchars($i['domaciprodukty']).",". htmlspecialchars($i['vody']).",". htmlspecialchars($i['sladkosti'])."],";
    }  
            ?>
        ]);

        var options = {
          title: 'Stav Potravin',
          hAxis: {title: 'Stav Databáze',  titleTextStyle: {color: '#333'}},
          vAxis: {minValue: 0}
        };

        var chart = new google.visualization.AreaChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
    </script> 
    
  </head>
  <body>
    <div id="chart_div" style="width: 100%; height: 500px;"></div>
    <script type="text/javascript" src="js/graf2.js"></script>
    <iframe src="analithics2.php" style="position: relative; width: 100%;height: 400px;" ></iframe>
   
  </body>
</html>