<?php 
include_once 'db.php';
if(!isset($_SESSION["jmeno"])){
    header("Location: uvod/index.html");
    die();
}

?><!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/w3.css">
        <meta charset="UTF-8">
        <title></title>
        <style>
            
            .nadpis{
                top: 0px;
                position: relative;
                left: 200px;
            }
            .input{
                position: relative;
                top: -70px; 
                border: none;
                border-radius: 4px;
            }
            .listatlacitko{
                position: relative;
                top: -70px;
                border: none;
                border-radius: 4px;
                height: 50px;
                width: 60px;
                left: 540px;
                background-image: url("lupa.png");
                background-size: 50px;
                background-position-x: 5px;
            }
            #vyhledatpodleeanu{
                margin: 0px;
                width: 400px;
                height: 50px;
                left: 600px;
            }
            p{
                font-family: arial;
                font-size: 20px;
            }
            .seznam{
    position: relative;
    text-align: center;
    top: 20px;
    left: 2px;
    overflow: auto;
}
            

.potravina{
    position: relative;
    display: block;
    width: 160px;
    height: 196px;
    margin: 2.5px;
    background-color: #999999;
}
.potravinatext{
    top: 10px;
    position: relative;
    font-family: arial;
    font-size: 15px;
    text-align: center;
    text-decoration: none;
    margin: 0px;
    width: 120px;
    height: 40px;
}
a{
     position: relative;
    text-decoration: none;
    margin: 0px;
    float: left;
}
.krizek{
    position: absolute;
    
                top: 2.5px;
                right: 2.5px;
                background-image: url("krizek.png");
                background-size: 15px;
                width: 15px;
                height: 15px;
                background-color: transparent;
                
            }
            .vratit{
                position: absolute;
                top: 0px;
                right: 0px;
                width: 500px;
                height: 50px;
                background: #cccccc;
                animation: priletnuti 1s ;
                transition: right 1s;
            }
            @keyframes priletnuti {
    from {right: -600px;}
    to {right: 0px;}
    
}
.pridatsean{
        position: relative;
        width: 70px;
        height: 70px;
        left: 25px;
        top: 10px;
        background-image: url("scanner.png");
        background-size: 70px;
        
    }
    .pridatbezean{
        position: relative;
        width: 70px;
        height: 70px;
        left: 25px;
        top: 15px;
        background-image: url("vytvor ean.png");
        background-size: 70px;
        
    }
                @media only screen and (max-width: 1000px) {
                #vyhledatpodleeanu{
                    left: 10px;
                    height: 50px;
                    width: 80%;
                }
                .nadpis{
               left: 20px;
            }
                form{
                    height: 0px;
                    position: relative;
                }
                .listatlacitko{
                     left: 5px;
                     top: -70px;
                }
                
                .seznam{
    position: relative;
    top: 2px;
    left: 2px;
    overflow: auto;

}
.vratit{
                position: absolute;
                top: 0px;
                right: 0px;
                width: 70%;
                height: 50px;
                background: #cccccc;
                animation: priletnuti 1s ;
                transition: right 1s;
            }
}
.ikonka{
    position: relative;
    width: 70px;
    left: 28px;
    top: 10px;
}
.prihlasovani{
    position: relative;
    right: 0px;
    width: 80px;
    height: 80px;
    background-image: url("https://image.flaticon.com/icons/png/512/64/64572.png");
    background-size: 100%;
}
.odhlasit{
    position: relative;
    width: 100%;
    text-align: center;
    margin-top: -20px;
}
.txt{
    position: relative;
    top: 10px;
    margin-bottom: 20px;
}
        </style>
    </head>
    <body style="background-color:#cccccc;">


<div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="mySidebar">
  <button class="w3-bar-item w3-button w3-large"
  onclick="w3_close()">Zavřít &times;</button>
<a href="index.php" class="w3-bar-item w3-button">Domů</a>
  <center><p>Filtrovat</p> </center>  <hr /> 
      
            <a href="hledatjmeno.php" class="w3-bar-item w3-button">Podle názvu</a>
  <a href="hledatkategorii.php" class="w3-bar-item w3-button">podle kategorie</a>
  <a href="hledatdatum.php" class="w3-bar-item w3-button">datum spotřeby</a>
  
  <center><p>Správa dat</p> </center>  <hr /> 
  
  <a href="zalohovani.php" class="w3-bar-item w3-button">Zálohování</a>
  <a href="import.php" class="w3-bar-item w3-button">Import</a>
  <a href="export.php" class="w3-bar-item w3-button">Export</a>
  <center><p>Správa databáze</p> </center>  <hr /> 
  
  <a href="ulozenepotraviny.php" class="w3-bar-item w3-button">Uložené potraviny</a>
  <a href="stalepotraviny.php" class="w3-bar-item w3-button">Stálé potraviny</a>
  <a href="nastaveni.php" class="w3-bar-item w3-button">nastavení</a>
</div>

        <div id="main" >

<div class="w3-teal" >
     
  <button id="openNav" class="w3-button w3-teal w3-xlarge" onclick="w3_open()">&#9776;</button>
  <div class="w3-container">
      
      <h1 class="nadpis">Export</h1>
      
  </div>
  
</div>  <center><div class="seznam">
    
        <a href="excel_export.php"><div  class="potravina"><img src="ikonky/excel.png" height="140"><p>Excel</p></div></a>
        <a href="" onclick="pdf()"><div  class="potravina"><img src="ikonky/pdf.png" height="140"><p>PDF</p></div></a>
        <a href="exportaction.php?eep=1"><div  class="potravina"><img src="uvod/paprikahola.png" height="140"><p>EEP</p></div></a>
        <a href="exportaction.php?txt=1"><div  class="potravina"><img src="ikonky/txt.png" height="120" class="txt"><p>TXT</p></div></a>
    
</div>
   </center>
</div>

  <?php
            if(isset($_GET['smazane'])){
                echo '<center><a href="vratitPotravinu.php?vracenapotravina='.$_GET['smazane'].'" id="vratit" class="vratit" onclick="zmiz();">Vrátit smazanou potravinu</a></center>';
            }
        ?>      
<script src="menu.js"></script>  
<script src="jquery-3.3.1.min.js"></script>
<script type="text/javascript">
    function pdf(){
        window.open("PDF_Export.php");
    }
                </script>


</body>
    </body>
</html>
