<?php 

include_once 'db.php';
include 'funkce.php';

if(!isset($_POST['jmeno']) or $_POST['jmeno']==NULL){
     $jmeno = "";
     $chyba = 0;
} else {
    $jmeno = $_POST['jmeno'];
    $chyba = 1;
}
if(!isset($_SESSION["jmeno"])){
    header("Location: uvod/index.html");
    die();
}

/*
CREATE TABLE `wwp`.`admin` ( `typ` VARCHAR(100) NOT NULL , `id` INT NOT NULL AUTO_INCREMENT , `ean` VARCHAR(500) NOT NULL , `jmeno` VARCHAR(200) NOT NULL , `kategorie` VARCHAR(100) NOT NULL , `spotreba` VARCHAR(100) NOT NULL , `mnozstvi` VARCHAR(100) NOT NULL , `jednotky` VARCHAR(100) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
 */
?><!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/w3.css">
<link rel="stylesheet" href="css/potraviny.css">
        <meta charset="UTF-8">
        <title></title>
        <style>
            .nadpis{
                top: 0px;
                position: relative;
                left: 200px;
            }
        </style>
    </head>
    <body style="background-color:#cccccc;">


        <div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="mySidebar">
  <button class="w3-bar-item w3-button w3-large"
  onclick="w3_close()">Zavřít &times;</button>
<a href="index.php" class="w3-bar-item w3-button">Domů</a>
  <center><p>Filtrovat</p> </center>  <hr /> 
      
            <a href="hledatjmeno.php" class="w3-bar-item w3-button">Podle názvu</a>
  <a href="hledatkategorii.php" class="w3-bar-item w3-button">podle kategorie</a>
  <a href="hledatdatum.php" class="w3-bar-item w3-button">datum spotřeby</a>
  
  <center><p>Správa dat</p> </center>  <hr /> 
  
  <a href="zalohovani.php" class="w3-bar-item w3-button">Zálohování</a>
  <a href="import.php" class="w3-bar-item w3-button">Import</a>
  <a href="export.php" class="w3-bar-item w3-button">Export</a>
  <center><p>Správa databáze</p> </center>  <hr /> 
  
  <a href="ulozenepotraviny.php" class="w3-bar-item w3-button">Uložené potraviny</a>
  <a href="stalepotraviny.php" class="w3-bar-item w3-button">Stálé potraviny</a>
  <a href="nastaveni.php" class="w3-bar-item w3-button">nastavení</a>
</div>

        <div id="main" >

<div class="w3-teal" >
  <button id="openNav" class="w3-button w3-teal w3-xlarge" onclick="w3_open()">&#9776;</button>
  <div class="w3-container">
      
      <h1 class="nadpis">Domácí sklad</h1>
      
  </div>

</div>  <form action="" method="post"><input type="text" class="input" id="vyhledatpodleeanu" name="jmeno" value="<?php echo $jmeno; ?>" placeholder="Vyhledet podle jména" autofocus><input type="submit" class="listatlacitko" value=" "></form>
<div class="seznam">
    <div  class="potravina"><a href="ean.php" class="pridatsean"></a><a href="vygenerovatEan.php" class="pridatbezean"></a></div>
    <?php
        $je = 0;
    /*$SQL = 'SELECT * FROM '.$_SESSION['jmeno'].' WHERE typ="potraviny"';
    $result = $db_conn->query($SQL);

    foreach($result as $key){
        if($jmeno == $key['jmeno']){
        $je = 1; 
        echo '<div  class="potravina">';
        
        if(htmlspecialchars($key["mnozstvi"])== NULL){
            $mnoz = NULL;
        }else{
            if(htmlspecialchars($key["mnozstvi"]) == 1){
                $mnoz = NULL;
            }else{
                $mnoz = "<br />(".htmlspecialchars($key["mnozstvi"])." ".htmlspecialchars($key["jednotky"]).")";
            }
        }
          
        switch (htmlspecialchars($key["kategorie"])){
            case "Ovoce":
                echo '<img src="ikonky/ovoce.png" class="ikonka">';
                break;
            case "Zelenia":
                echo '<img src="ikonky/zelenina.png" class="ikonka">';
                break;
            case "maso":
                echo '<img src="ikonky/maso.png" class="ikonka">';
                break;
            case "konzervy":
                echo '<img src="ikonky/konzervy.png" class="ikonka">';
                break;
            case "mléčné výrobky":
                echo '<img src="ikonky/mlecnevyrobky.png" class="ikonka">';
                break;
            case "sypké suroviny":
                echo '<img src="ikonky/sypkesuroviny.png" class="ikonka">';
                break;
            case "tekuté suroviny":
                echo '<img src="ikonky/tekutesiroviny.png" class="ikonka">';
                break;
            case "domácí produkty":
                echo '<img src="ikonky/domacivyrobky.png" class="ikonka">';
                break;
            case "vody":
                echo '<img src="ikonky/vody.png" class="ikonka">';
                break;
            case "sladkosti":
                echo '<img src="ikonky/sladkosti.png" class="ikonka">';
                break;
        }

        $jmeno = NULL;
        $pole = explode(" ", htmlspecialchars($key["jmeno"]));
        for($j=0;$j<count($pole);$j++){
            if($j < 2){
            if(strlen($pole[$j]) > 10){
                $jmeno = $jmeno.substr($pole[$j],10)."...<br />";
            } else {
                $jmeno = $jmeno." ".$pole[$j];
            }   
            }
        }

        echo '<a href="smazatPotravinu.php?id='.htmlspecialchars($key["id"]).'" class="krizek"></a><a href="upravit.php?id='.htmlspecialchars($key["id"]).'" class="potravinatext">'. $jmeno.$mnoz.'</a>';
        if(htmlspecialchars($key["spotreba"]) != "..20"){
        echo '<a class="potravinatext">'. htmlspecialchars($key["spotreba"]).'</a>';
        }
        echo '</div>';
        }
    }*/
    $SQL = 'SELECT * FROM '.$_SESSION['jmeno'].' WHERE typ="potraviny"';
    $result = $db_conn->query($SQL);
    if($jmeno != ""){
    foreach($result as $key){
        if(strpos(htmlspecialchars($key['jmeno']), $jmeno )!== false){
        $je = 1;
        echo '<div  class="potravina">';
        
        if(htmlspecialchars($key["mnozstvi"])== NULL){
            $mnoz = NULL;
        }else{
            if(htmlspecialchars($key["mnozstvi"]) == 1){
                $mnoz = NULL;
            }else{
                $mnoz = "<br />(".htmlspecialchars($key["mnozstvi"])." ".htmlspecialchars($key["jednotky"]).")";
            }
        }
          
        echo kategorie($db_conn,htmlspecialchars($key["kategorie"]));

        $jmeno2 = "";
        $pole = explode(" ", htmlspecialchars($key["jmeno"]));
        for($j=0;$j<count($pole);$j++){
            if($j < 2){
            if(strlen($pole[$j]) > 10){
                $jmeno2 = $jmeno2.substr($pole[$j],10)."...<br />";
            } else {
                $jmeno2 = $jmeno2." ".$pole[$j];
            }   
            }
        }

        echo '<a href="smazatPotravinu.php?id='.htmlspecialchars($key["id"]).'" class="krizek"></a><a onclick="upravit('.htmlspecialchars($key["id"]).')" class="potravinatext">'. $jmeno2.$mnoz.'</a>';
        if(htmlspecialchars($key["spotreba"]) != "..20"){
        echo '<a class="potravinatext">'. htmlspecialchars($key["spotreba"]).'</a>';
        }
        echo '</div>';
        }
    }
    }
    if($je == 0){
        if($chyba == 1){
        echo '<p>Se jménem: "'.$jmeno.'" nebyla nalezena žádná potravina</p>';
        }
    }
    ?>
    
</div>
   
</div>

  <?php
            if(isset($_GET['smazane'])){
                echo '<center><a href="vratitPotravinu.php?vracenapotravina='.$_GET['smazane'].'" id="vratit" class="vratit" onclick="zmiz();">Vrátit smazanou potravinu</a></center>';
            }
        ?>      
        
<script src="menu.js"></script>
<script src="jquery-3.3.1.min.js"></script>
    <div class="uprava" id="uprava"><div class="krizek" onclick="zavritupravovani()"></div><iframe id="iframe"src=""></iframe></div>
        <script type="text/javascript">
        document.getElementById("uprava").style.display = 'none'; 
        function upravit(id){
        document.getElementById("iframe").src = 'upravit.php?id='+id; 
        document.getElementById("uprava").style.display = 'inline-block'; 
        }
        function zavritupravovani(){
            document.getElementById("uprava").style.display = 'none'; 
        }
        window.addEventListener("message", receiveMessage, false);
        function receiveMessage(event) {
         if (event.data === "zavrit"){
             document.getElementById("uprava").style.display = 'none'; 
             location.reload();
         }
 
      return;
}
</script>


</body>
    </body>
</html>
