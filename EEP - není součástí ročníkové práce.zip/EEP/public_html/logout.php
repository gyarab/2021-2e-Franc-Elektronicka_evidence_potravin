<?php
session_start();

unset($_SESSION["jmeno"]);
if(isset($_COOKIE['jmeno'])){
    unset($_COOKIE['jmeno']);
    setcookie('jmeno', '', time() - 3600);
    unset($_COOKIE['heslo']);
    setcookie('heslo', null, time() - 3600);
}
header("Location: uvod/index.html");