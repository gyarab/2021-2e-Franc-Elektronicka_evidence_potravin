<?php
include_once 'db.php';
//require 'tfpdf + UTF-8/tfpdf.php';
require'tfpdf/tfpdf.php';

$jmeno = $_SESSION["jmeno"];
$pocet=0;

$pdf = new tFPDF();
$pdf->AddPage();

$pdf->SetTitle("Evidence potravin ".$jmeno." ".date("d.m.Y"),true);
$pdf->SetAutoPageBreak(true,20);
$pdf->AddFont('Releway','','Raleway-Bold.ttf', true);
$pdf->SetFont('Releway','',25);
$pdf->Image('uvod/paprikahola.png',5,0,45);
$pdf->text(68,25,"Elektronická Evidence Potravin");
$pdf->SetTextColor(150, 150, 150);
$pdf->SetFont('Releway','',12);
$pdf->text(68,32,"$jmeno");
$pdf->text(178,32,date("d.m.Y"));
$pdf->Line(15, 45, 200, 45);
$pdf->SetTextColor(0, 0, 0);
$pdf->SetY(50);

$SQL = 'SELECT * FROM '.$_SESSION["jmeno"].' WHERE typ="potraviny" ORDER BY jmeno;';
$result = $db_conn->query($SQL);
foreach ($result as $i){
    $nazev = htmlspecialchars($i["jmeno"]);
    if(strlen(htmlspecialchars($i["jmeno"]))>30){
        $nazev = substr(htmlspecialchars($i["jmeno"]),0,30)."...";
    }
    $kategorie = htmlspecialchars($i["kategorie"]);
    if(strlen(htmlspecialchars($i["kategorie"]))>5){
        $kategorie = substr(htmlspecialchars($i["kategorie"]),0,5).".";
    }
    if(htmlspecialchars($i["ean"]) == ""){
        $ean = "";
    }elseif(!is_numeric(htmlspecialchars($i["ean"])[0])){
        $ean = "";
        //echo $ean."jop<br>";
    }/*elseif (!$pdf->TestCheckDigit(intval(htmlspecialchars($i["ean"])))) {
        $ean = "";
        //echo $ean."ano<br>";
    }*/else{
        $ean = htmlspecialchars($i["ean"]);
        //echo $ean."<br>";
    }
    $barva = explode(",",prochazi(htmlspecialchars($i["spotreba"])));
    $pdf->SetX(15);
    $pdf->SetFont('Releway','',12);
    $pdf->Cell(70,10, $nazev,1,"L","L");
    $pdf->Cell(10,10, htmlspecialchars($i["mnozstvi"]),1,"R","C");
    $pdf->Cell(10,10, htmlspecialchars($i["jednotky"]),1,"L","C");
    $pdf->Cell(25,10, htmlspecialchars($i["spotreba"]),1,"L","L");
    $pdf->SetFillColor($barva[0],$barva[1],$barva[2]);
    $pdf->Cell(3,10, "",1,"L","L",1);
    $pdf->SetFillColor(0,0,0);
    $pdf->Cell(15,10, $kategorie,1,"L","L");
    if($ean == "" or $ean == 0){
        $pdf->Cell(42,10,"",1,"L","L");
    }else{
        $pdf->Cell(42,10, $pdf->EAN13(150,$pdf->GetY()+1,$ean,7),1,"L","L");
    }
    $pdf->Cell(10,10,"",1,"L","L");
    
    
    $pdf->SetY($pdf->GetY()+10);
    $pocet++;
}



$pdf->Output();


function prochazi($spotreba){
    if($spotreba !== ""){
    $cele = explode(".",$spotreba);
                  $d1 = $cele[0];
                  if($cele[0]<10){
                      $d1 = "0".$cele[0];
                  }
                  $d2 = $cele[1];
                  if($cele[1]<10){
                      $d2 = "0".$cele[1];
                  }
                  $d3 = $cele[2];
                  $cele = $d3.$d2.$d1;
        $barva = "255,255,255";

        $date = new DateTime(date("Y-m-d"));
        $interval = new DateInterval("P7D");
        $date->add($interval);

        if($cele < $date->format("Ymd"))
            $barva = "249, 103, 20";
        
        if($cele < date("Ymd"))
            $barva = "158, 16, 48";
    }else{
        $barva = "255, 255, 255";
    }
        
        if($spotreba == "0.0.0")
            $barva = "255, 255, 255";
        
        return $barva;
}