<?php
include_once '../db.php';
if(!isset($_SESSION["jmeno"])){
    header("Location: uvod/index.html");
    die();
}
 
//--------------------------------------------  Kontrola prichozich dat  -------------------------------------------------------------
if(isset($_POST['ean'])){   
            if(strlen($_POST['ean']) > 200){
                header("Location: pridat.php?zprava="."ean nasmí být delší než 200 znaků.");
                die();
            }
            }
if(isset($_POST['jmeno'])){   
            if(strlen($_POST['jmeno']) > 50){
                header("Location: pridat.php?zprava="."jméno nasmí být delší než 50 znaků.");
                die();
            }
            }
if(isset($_POST['den'])){   
            if(strlen($_POST['den']) > 200){
                header("Location: pridat.php?zprava="."den nasmí být delší než 200 znaků.");
                die();
            }
            } 
if(isset($_POST['mesic'])){   
            if(strlen($_POST['mesic']) > 200){
                header("Location: pridat.php?zprava="."měsíc nasmí být delší než 200 znaků.");
                die();
            }
            }
if(isset($_POST['rok'])){   
            if(strlen($_POST['rok']) > 200){
                header("Location: pridat.php?zprava="."rok nasmí být delší než 200 znaků.");
                die();
            }
            }
if(isset($_POST['mnozstvi'])){   
            if(strlen($_POST['mnozstvi']) > 200){
                header("Location: pridat.php?zprava="."množství nasmí být delší než 200 znaků.");
                die();
            }
}
//--------------------------------------------  pridani do database  -------------------------------------------------------------------
            
            $spotreba = intval($_POST['den']).".".intval($_POST['mesic']).".".intval($_POST['rok']);
            
            if($spotreba == "0.0.20"){
                $spotreba = "";
            }
            
             
             
             
             
             if(!isset($_POST['barcode'])){
                 $SQL = "INSERT INTO ".$_SESSION['jmeno']." (typ,jmeno,kategorie,spotreba,mnozstvi,jednotky) VALUES ('potraviny','".$_POST['jmeno']."','".$_POST['kategorie']."','".$spotreba."','".$_POST['mnozstvi']."','".$_POST['jednotka']."');";
             $result = $db_conn->query($SQL);
                 include_once '../ulozanalithics.php';
             header("Location: ../index.php");
             die();
             }else{
                 
                 $jmeno = NULL;
                 $SQL = 'SELECT * FROM jmena WHERE jmeno="'.$_POST['jmeno'].'";';
                 $result = $db_conn->query($SQL);
                 foreach ($result as $i){
                 $jmeno = htmlspecialchars($i["jmeno"]);
                 $jmenoid = htmlspecialchars($i["id"]);
                 }
                 
                 if($jmeno == NULL){
                    $SQL = "INSERT INTO jmena (jmeno) VALUES ('".$_POST['jmeno']."');";
                    $result = $db_conn->query($SQL);
                    
                    $SQL = 'SELECT * FROM jmena WHERE jmeno="'.$_POST['jmeno'].'";';
                    $result = $db_conn->query($SQL);
                   foreach ($result as $i){
                   $jmenoid = htmlspecialchars($i["id"]);
                     }
                   }
                   switch ($_POST['kategorie']){
                   case "kategorie": 
                       $kategorie = 0;
                       break;
                   case "ovoce": 
                       $kategorie = 1;
                       break;
                   case "Zelenia": 
                       $kategorie = 2;
                       break;
                   case "sypké suroviny": 
                       $kategorie = 3;
                       break;
                   case "tekuté suroviny": 
                       $kategorie = 4;
                       break;
                   case "maso": 
                       $kategorie = 5;
                       break;
                   case "mléčné výrobky": 
                       $kategorie = 6;
                       break;
                   case "konzervy": 
                       $kategorie = 7;
                       break;
                   case "domácí produkty": 
                       $kategorie = 8;
                       break;
                   case "vody": 
                       $kategorie = 9;
                       break;
                   default:
                       $kategorie = 0;
                       break;
                   }
                   switch ($_POST['jednotka']){
                   case "ks": 
                       $jednotky = 1;
                       break;
                   case "kg": 
                       $jednotky = 2;
                       break;
                   case "ml": 
                       $jednotky = 3;
                       break;
                   case "l": 
                       $jednotky = 4;
                       break;
                   case "%": 
                       $jednotky = 5;
                       break;
                   }
            
                 $ean = "eep.".$jmenoid.".".$kategorie.".".$spotreba.".".$jednotky;
                 $SQL = "INSERT INTO ".$_SESSION['jmeno']." (typ,ean,jmeno,kategorie,spotreba,mnozstvi,jednotky) VALUES ('potraviny','".$ean."','".$_POST['jmeno']."','".$_POST['kategorie']."','".$spotreba."','".$_POST['mnozstvi']."','".$_POST['jednotka']."');";
             $result = $db_conn->query($SQL);
                 echo $ean;
             }
            


?>
<html>
					  <head>
					  <title>PHP Barcode Generator Script</title>
					  <link rel="stylesheet" type="text/css" href="style.css">
					  <script src='jquery.js'></script>
					  </head>
					  <body>
					  <div class='resp_code'>
					  
					 
					  <script type='text/javascript'>
                                             
                                            
                                            
                                              
					  function chk(){
					  var sds = document.getElementById("dum");
					  if(sds == null){
						  alert("You are using a free package.\n You are not allowed to remove the tag.\n");
					  }
					  var sdss = document.getElementById("dumdiv");
					  if(sdss == null){
						  alert("You are using a free package.\n You are not allowed to remove the tag.\n");
						  document.getElementById("content").style.visibility="hidden";
					  }
					  }
					  window.onload=chk;
					  function get_barcode()
					  {
						  var str = document.getElementById('txtstr').value;
						var siz = document.getElementById('txtsize').value;
						var orientation = $("#orientation option:selected" ).text();
						var codetype = $("#codetype option:selected" ).text();
						if (str=='' || siz=='') {
						 alert("Enter values properly!");
						}
						else if (codetype=='Codabar') {							   								 
						  var regex = /^[0-9?=.$\/+-:]+$/;
						  if (!regex.test($("#txtstr").val())){
							alert("Codabar Accepts Only 0-9 and .$/+-:");
							document.getElementById('txtstr').value='';
						  }
						  else{
							$.ajax({
									  type: "POST",
									  url: "barcode.php",
									  data:{str:str,size:siz,orientation:orientation,codetype:codetype},
									  success: function(data){
									// alert(data);
									 if (data) {
									 $('#maindiv').html(data);
									//window.localtion.reload();
									document.getElementById('txtstr').value='';
									document.getElementById('txtsize').value='';
									
									 }               
									  }
								  })
						  }
						}		
						else
						{
                                                    
											$('.load').show();
											$("#btn").hide();
							  $.ajax({
									  type: "POST",
									  url: "barcode.php",
									  data:{str:str,size:siz,orientation:orientation,codetype:codetype},
									  success: function(data){
									// alert(data);
									 if (data) {
									 $('#maindiv').html(data);
									//window.localtion.reload();
									document.getElementById('txtstr').value='';
									document.getElementById('txtsize').value='';
									
									 }               
									  },
									  complete: function(){
                                                                              location.replace("zobrazvygenerovane.php? ean=<?php echo $ean."& mnozstvi=".$_POST['mnozstvi'];   ?>");
											$('.load').hide();
											$("#btn").show();                     
											}
								  })
						}			
					  }
					  function checnum(as)
					  {
						var dd = as.value;
						if(dd.lastIndexOf(" ")>=0){dd = dd.replace(" ","");as.value = dd;
						}
						if(isNaN(dd))
						{
						dd = dd.substring(0,(dd.length-1));
						as.value = dd;
						}
					  }
					   function validateForm()
					   {
						var str = document.getElementById('txtstr').value;
						var siz = document.getElementById('txtsize').value;
						if (str=='' || siz=='') {
						 alert("Enter values properly!");
						 return false;
						}
						else
						{
						 return true;
						 window.reload;
						}  
					  }
                                          
					  </script>
                                          <center>
                                              <div style="position: relative;" style="display: none;">
                                          <div align='center' class='frms noborders' id='content'>
                                              <section style="display: none;">
                                              <b>Enter String : </b><input type='text' name='string' maxlength='25' id='txtstr' value="<?php echo $ean; ?>" autocomplete='off'><br>
					   <b>Select Orientation : </b>
					   <select name='orientation' id='orientation'>
						<option>Horizontal</option>
						<option>Vertical</option>
					   </select>
					   <b>Select CodeType: </b>
					   <select name='codetype' id='codetype'>
                                               <option>Code128</option>
                                               <option>Code25</option>
                                               <option>Code39</option>
                                               <option>Codabar</option>
					   </select><br>
                                           
                                           <b>Enter Size : </b><input type='text' name='size' maxlength='3' onkeyup=checnum(this) id='txtsize' value="120" autocomplete='on'>
					   <div align='center'>
											<div class='load' style='display:none;'><img src='barcode-generator/loading.gif'></div>
											<input type='submit' value='Get Barcode' onclick='get_barcode();' id='btn'>
					   </div><br>
                                              </section>
					  <div align='center' id='maindiv'></div>
					   </div>
                                              </div>
                                          </center>
                                          <div  align='center' style="font-size: 10px;color: #dadada;" id="dumdiv" style="display: none;">
					  <a href="http://www.hscripts.com" id="dum" style="font-size: 10px;color: #dadada;text-decoration:none;color: #dadada;">&copy;h</a>
					  </div>
					  </div>
                                              <script type="text/javascript">
                                              
                                              get_barcode();
                                               </script>
					  </body>
</html>

