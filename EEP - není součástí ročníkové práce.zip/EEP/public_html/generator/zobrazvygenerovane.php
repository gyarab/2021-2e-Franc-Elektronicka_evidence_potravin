<?php 
if(!isset($_GET['ean'])){
    
}
include_once '../ulozanalithics.php';
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0">

        <title></title>
        <style>
           .bg{
                
                position: relative;
                top: 200px;
                width: 60%;
                height: 450px;
                background-color: #999999;
                border-radius: 3px;
            }

            .dalsi{
                position: relative;
                color: #666666;
                border: none;
                border-radius: 3px;
                width: 29.5%;
                height: 40px;
                font-size: 22px;
            }
            #zpet{
                top: 80px;
                color: #666666;
                font-size: 22px;
                right: 15%;}
            #dalsi{
                top: 40px;
                color: #666666;
                font-size: 22px;
                right: -15%;}
            #tisk{
                top: -50px;
                color: #666666;
                font-size: 22px;
                width: 60%;
                right: 0%;}
            .obr{
                position: relative;
                top: 50px;
                width: 30%;
                border-radius: 4px;
            }
            .text{
               position: relative; 
               font-family: arial;
               font-size: 20px;
               top: 30px;
            }
            @media screen and (max-width: 750px){
                .bg{
                position: absolute;
                top: 0px;
                left: 0px;
                width: 100%;
                height: 100%;
                background-color: #999999;
                border-radius: 3px;
            }
            .obr{
                position: relative;
                top: 50px;
                width: 60%;
                border-radius: 4px;
            }
            }
        </style>
    </head>
    <body>
        
    <center>
        <div class="bg">
            <img class="obr" src="image/<?php echo $_GET['ean'].".png";  ?>"/>
            <p class="text"><?php echo $_GET['ean'];  ?></p>
            <form method="post" action="../vygenerovatEan.php">
            <input type="submit" value="Zpět" class="dalsi" id="zpet">
            </form>
            <form action="../index.php">
            <input type="submit" value="Hotovo" class="dalsi" id="dalsi">
            </form>
            
            <input onclick="presmerovani()" type="submit" value="Tisk" class="dalsi" id="tisk">
            <script type="text/javascript">
            function presmerovani(){
            window.open("tisk.php? ean=<?php echo $_GET['ean']; ?>&mnozstvi=<?php echo $_GET['mnozstvi']; ?>");}</script>

            
        </div>
    </center>
    </body>
</html>
