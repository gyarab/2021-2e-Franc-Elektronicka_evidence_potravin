<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <style>
            .barcod{
                margin: 4px;
                float: left;
                width: 200px;
                height: 70px;
                position: relative;
                margin-top: 12px;
                
            }
            .obr{
                position: relative;
                width: 200px;
                height: 70px;
            }
            .text{
                position: relative;
                float: top;
                top: -17px;
                text-align: center;
                font-family: arial;
                font-size: 12px;
            }
        </style>
    </head>
    <body>
        <?php
        if($_GET['mnozstvi'] == NULL){
        $mnozstvi = 1;
        }else{
            $mnozstvi = $_GET['mnozstvi'];
        }
        for($i=0; $i<$mnozstvi;$i ++){
            echo '<div class="barcod">
   <img class="obr" src="image/'.$_GET['ean'].'.png"/>
   <p class="text">'.$_GET['ean'].'</p>
        </div>';
        }
        
        ?>
        <script type="text/javascript" >
        window.print();
        </script>
    </body>
</html>
