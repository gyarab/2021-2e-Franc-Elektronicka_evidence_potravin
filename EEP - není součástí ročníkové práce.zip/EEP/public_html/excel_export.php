<?php
include_once 'db.php';
require 'PHPExcel/PHPExcel.php';
require "PHPExcel/PHPExcel/Writer/Excel5.php"; 

$excel = new PHPExcel();
$excel ->setActiveSheetIndex(0);

$SQL = 'SELECT * FROM '.$_SESSION["jmeno"].' WHERE typ="potraviny";';
$result = $db_conn->query($SQL);

$excel->getActiveSheet()
                ->setCellValue("A2", "jmeno")
                ->setCellValue("B2", "spotreba")
                ->setCellValue("C2", "kategorie")
                ->setCellValue("D2", "mnozstvi")
                ->setCellValue("E2", "jednotky")
                ->setCellValue("F2", "ean")
                ;

$pocet = 0;
foreach ($result as $i){
    $ean = htmlspecialchars($i["ean"]);
        $excel->getActiveSheet()
                ->setCellValue("A".($pocet+3), htmlspecialchars($i["jmeno"]))
                ->setCellValue("B".($pocet+3), htmlspecialchars($i["spotreba"]))
                ->setCellValue("C".($pocet+3), htmlspecialchars($i["kategorie"]))
                ->setCellValue("D".($pocet+3), htmlspecialchars($i["mnozstvi"]))
                ->setCellValue("E".($pocet+3), htmlspecialchars($i["jednotky"]))
                ->setCellValue("F".($pocet+3), "$ean",PHPExcel_Cell_DataType::TYPE_NUMERIC)
                ;
        $excel->getActiveSheet()->getStyle("F".($pocet+3))
        ->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1); 
        $excel->getActiveSheet()->getStyle("F".($pocet+3))->getNumberFormat()->setFormatCode('0'); 
        $pocet++;
}
$excel->getActiveSheet()->getColumnDimension("A")->setWidth(25);
$excel->getActiveSheet()->getColumnDimension("F")->setWidth(20);
/*$excel->getActiveSheet()->getStyle('B3:B'.$pocet+3)
    ->getNumberFormat()
    ->setFormatCode(
        PHPExcel_Style_NumberFormat::FORMAT_DATE_DATETIME
    );
*/

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="Elektronicka_ Evidence_Potravin_'.$_SESSION["jmeno"].'.xls"');
$file = PHPExcel_IOFactory::createWriter($excel,'Excel5');

$file->save('php://output');

header("Location: export.php");