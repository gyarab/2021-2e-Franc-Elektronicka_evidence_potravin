<?php
include_once 'db.php';
include 'funkce.php';
include_once 'potravina.php';

if (!isset($_POST['ean']) or $_POST['ean'] == NULL) {
    header("Location: index.php");
    die();
}
if (!isset($_SESSION["jmeno"])) {
    header("Location: uvod/index.html");
    die();
}
$ean = $_POST['ean'];
$ean = str_replace("+", "1", $ean);
$ean = str_replace("ě", "2", $ean);
$ean = str_replace("š", "3", $ean);
$ean = str_replace("č", "4", $ean);
$ean = str_replace("ř", "5", $ean);
$ean = str_replace("ž", "6", $ean);
$ean = str_replace("ý", "7", $ean);
$ean = str_replace("á", "8", $ean);
$ean = str_replace("í", "9", $ean);
$ean = str_replace("é", "0", $ean);
/*
  CREATE TABLE `wwp`.`admin` ( `typ` VARCHAR(100) NOT NULL , `id` INT NOT NULL AUTO_INCREMENT , `ean` VARCHAR(500) NOT NULL , `jmeno` VARCHAR(200) NOT NULL , `kategorie` VARCHAR(100) NOT NULL , `spotreba` VARCHAR(100) NOT NULL , `mnozstvi` VARCHAR(100) NOT NULL , `jednotky` VARCHAR(100) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
 */
?><!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/w3.css">
        <link rel="stylesheet" href="css/potraviny.css">
        <meta charset="UTF-8">
        <title></title>
        <style>
            .nadpis{
                top: 0px;
                position: relative;
                left: 200px;
            }
        </style>
    </head>
    <body style="background-color:#cccccc;">


        <div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="mySidebar">
            <button class="w3-bar-item w3-button w3-large"
                    onclick="w3_close()">Zavřít &times;</button>
            <a href="index.php" class="w3-bar-item w3-button">Domů</a>
            <center><p>Filtrovat</p> </center>  <hr /> 

            <a href="hledatjmeno.php" class="w3-bar-item w3-button">Podle názvu</a>
            <a href="hledatkategorii.php" class="w3-bar-item w3-button">podle kategorie</a>
            <a href="hledatdatum.php" class="w3-bar-item w3-button">datum spotřeby</a>

            <center><p>Správa dat</p> </center>  <hr /> 

            <a href="zalohovani.php" class="w3-bar-item w3-button">Zálohování</a>
            <a href="import.php" class="w3-bar-item w3-button">Import</a>
            <a href="export.php" class="w3-bar-item w3-button">Export</a>
            <center><p>Správa databáze</p> </center>  <hr /> 

            <a href="ulozenepotraviny.php" class="w3-bar-item w3-button">Uložené potraviny</a>
            <a href="stalepotraviny.php" class="w3-bar-item w3-button">Stálé potraviny</a>
            <a href="nastaveni.php" class="w3-bar-item w3-button">nastavení</a>
        </div>

        <div id="main" >

            <div class="w3-teal" >
                <button id="openNav" class="w3-button w3-teal w3-xlarge" onclick="w3_open()">&#9776;</button>
                <div class="w3-container">

                    <h1 class="nadpis">Domácí sklad</h1>

                </div>

            </div>  <form action="" method="post"><input type="text" class="input" id="vyhledatpodleeanu" name="ean" value="" placeholder="<?php
                if (isset($ean)) {
                    echo $ean;
                } else {
                    echo 'Vyhledet podle eanu';
                }
                ?>" autofocus><input type="submit" class="listatlacitko" value=" "></form>
            <div class="seznam">
                <div  class="potravina"><a href="ean.php" class="pridatsean"></a><a href="vygenerovatEan.php" class="pridatbezean"></a></div>
                <?php
                $SQL = 'SELECT * FROM ' . $_SESSION['jmeno'] . ' WHERE typ="potraviny" AND ean="'.$ean.'";';
                $result = $db_conn->query($SQL);
                foreach ($result as $i) {
                    $potravina = new Potravina(htmlspecialchars($i["id"]), htmlspecialchars($i["jmeno"]), htmlspecialchars($i["kategorie"]), htmlspecialchars($i["spotreba"]), htmlspecialchars($i["mnozstvi"]), htmlspecialchars($i["jednotky"]));
                    echo $potravina->htmlPotravina();
                    $funguje = 0;
                }
                if (!isset($funguje)) {
                    echo '<p>S ean kódem: ' . $_POST['ean'] . ' nebyla nalezena žádná potravina</p>';
                }
                ?>

            </div>

        </div>

        <?php
        if (isset($_GET['smazane'])) {
            echo '<center><a href="vratitPotravinu.php?vracenapotravina=' . $_GET['smazane'] . '" id="vratit" class="vratit" onclick="zmiz();">Vrátit smazanou potravinu</a></center>';
        }
        ?>      

        <script src="menu.js"></script>
        <script src="jquery-3.3.1.min.js"></script>

        <div class="uprava" id="uprava"><h3 class="upravaNadpis">Upravit</h3><div class="krizek" onclick="zavritupravovani()"></div><iframe id="iframe"src=""></iframe></div>
        <script type="text/javascript">
            document.getElementById("uprava").style.display = 'none';
            function upravit(id) {
                document.getElementById("iframe").src = 'upravit.php?id=' + id;
                document.getElementById("uprava").style.display = 'inline-block';
            }
            function zavritupravovani() {
                document.getElementById("uprava").style.display = 'none';
            }
            window.addEventListener("message", receiveMessage, false);
            function receiveMessage(event) {
                if (event.data === "zavrit") {
                    document.getElementById("uprava").style.display = 'none';
                    location.reload();
                }

                return;
            }
        </script>
    </body>
</body>
</html>
