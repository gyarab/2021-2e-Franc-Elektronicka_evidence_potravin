<?php
session_start();
if (isset($_GET['jmeno'])) {
    $_SESSION['jmeno'] = $_GET['jmeno'];
    $_SESSION['heslo'] = $_GET['heslo'];
} else {
    if (!isset($_SESSION["jmeno"])) {
        header("Location: uvod/index.html");
        die();
    }
}
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0">
        <script src="https://unpkg.com/html5-qrcode"></script>
        <link rel="stylesheet" href="css/w3.css">
        <link rel="stylesheet" href="css/formulare.css">
        <link rel="stylesheet" href="css/fonts.css">
        <title>Skenování EAN kódu</title>
        <style>
            .bg{
                position: relative;
                top: 10px;
                width: 700px;
                height: 800px;
                background-color:#0E273C;
                box-shadow: 0px 0px 10px gray;
                border-radius: 2px;
            }
            .nadpis5{
                padding-right: 150px;
            }
            .nadpis6{
                position: absolute;
                top: 70px;
                left: 50px;
            }
            .ctecka{
                position: relative;
                top: 180px;
            }
            .sirsi{
                    position: relative;
                    top: 170px;
                    left: 0px;
                    margin-bottom: 30px;
                }
            @media screen and (max-width: 1000px){
                .bg{
                    position: absolute;
                    top: 0px;
                    width: 100%;
                    height: 100%;
                    background-color: #0E273C;
                    left: 0px;
                }
                .sirsi{
                    top: 200px;
                }
                .nadpis5{
                    font-size: 30px;
                }
                .nadpis6{
                    padding-top: 50px;
                    font-size: 60px;
                    margin-bottom: 80px;
                }
            }
        </style>
    </head>
    <body>

    <center>
        <div class="bg">
            <a href="index.php" class="nadpis5">elektronická evidence potravin</a>
            <h2 class="nadpis6">Načíst EAN kód</h2>
            <?php
            if (isset($_GET['zprava'])) {
                echo ' <p class="error" >' . $_GET['zprava'] . '</p>';
            }
            ?>

            <form method="post" action="pridat.php" id="formularEan">
                <input type="text" id="ean" name="ean" class="w3-input sirsi" placeholder="ean:" autofocus />
                <input type="submit" value="Další" class="w3-input heslo2 sirsi">
                <div id="qr-reader" class="ctecka" style="width:500px"></div>
                <div id="qr-reader-results"></div>
                
                
            </form>
        </div>
    </center>
    <script type="text/javascript">
        var resultContainer = document.getElementById('qr-reader-results');
        var lastResult, countResults = 0;

        function onScanSuccess(decodedText, decodedResult) {
            if (decodedText !== lastResult) {
                ++countResults;
                lastResult = decodedText;
                // Handle on success condition with the decoded message.
                console.log(`Scan result ${decodedText}`, decodedResult);
                document.getElementById("ean").value = decodedText;
                document.getElementById("formularEan").submit();
            }
        }

        var html5QrcodeScanner = new Html5QrcodeScanner(
                "qr-reader", {fps: 10, qrbox: 250});
        html5QrcodeScanner.render(onScanSuccess);
    </script>
</body>
</html>
