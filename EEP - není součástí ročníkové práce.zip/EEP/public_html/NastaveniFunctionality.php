<?php
include_once 'db.php';

if(isset($_GET['heslo'])){
    $SQL = 'UPDATE uzivatele SET heslo="'.$_GET['heslo'].'" WHERE jmeno="'.$_SESSION['jmeno'].'";';
    $result = $db_conn->query($SQL);
    header("Location: nastaveni.php");
}
if(isset($_GET['zalohovani'])){
    if($_GET['zalohovani'] == "true"){
        $vysledek = "1";
    } else {
        $vysledek = "0";
    }
    if($_GET['upozorneni'] == "true"){
        $upozorneni = $_GET['kdyprojde'];
    } else {
        $upozorneni = "";
    }
    $SQL = 'UPDATE uzivatele SET autozalohovani="'.$vysledek.'", autoupozornrninaexpiraci="'.$upozorneni.'"  WHERE jmeno="'.$_SESSION['jmeno'].'";';
    $result = $db_conn->query($SQL);
    header("Location: nastaveni.php");
}
if(isset($_GET["pridatkategorii"])){
    if($_GET["pridatkategorii"] != ""){
    $SQL = 'INSERT INTO '.$_SESSION['jmeno'].' (typ,jmeno,poznamky) VALUES ("kategorie","'.$_GET["pridatkategorii"].'","'.$_GET["ikonka"].'");';
    $result = $db_conn->query($SQL);
    }
    header("Location: nastaveni.php");
}
if(isset($_GET["odstranitkategorii"])){
    $SQL = 'DELETE FROM '.$_SESSION['jmeno'].' WHERE id='.$_GET["odstranitkategorii"].';';
    $result = $db_conn->query($SQL);
    header("Location: nastaveni.php");
}