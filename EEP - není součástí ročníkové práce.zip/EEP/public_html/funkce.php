<?php
include_once 'db.php';
function Vyhledej_produkt_podle_ean($vstup){
$homepage = file_get_contents('https://app.zenserp.com/api/v2/search?apikey=4d488ec0-c07c-11ea-bf80-2361a4abcdb0&q='.$vstup.'&device=desktop&hl=cs&location=Prague,Prague,Czechia');

$reklamy=array(" - Tesco.ie");

$odděleno = explode('"title":"',$homepage);
$odděleno2 = explode('","url',$odděleno[1]);

$odděleno2[0] = str_replace($reklamy,"",$odděleno2[0]);
$vystup = explode(' | ',$odděleno2[0]);
return $vystup[0];
}
function Vyhledej_popis_podle_nazvu($vstup){
$homepage = file_get_contents('https://app.zenserp.com/api/v2/search?apikey=4d488ec0-c07c-11ea-bf80-2361a4abcdb0&q='.urlencode($vstup).' rohlik.cz&device=desktop&hl=cs&location=Prague,Prague,Czechia');
//echo $homepage;
$odděleno = explode('- Rohlík","url":"',$homepage);
$URL = explode('","destination',$odděleno[1]);
$homepage = file_get_contents(str_replace("\\",'',$URL[0]));
//echo $homepage;

$odděleno = explode('<div id="productDetailDescription"',$homepage);
$odděleno2 = explode('class="ckContent">',$odděleno[1]);
$odděleno3 = explode('<div class="sc-109swx7-0 hJjVFf">',$odděleno2[1]);
return $odděleno3[0];
}
function sloucit($db_conn){
    $blacklist = array();
    
    $SQL = 'SELECT * FROM '.$_SESSION["jmeno"].' WHERE typ="potraviny";';
    $result = $db_conn->query($SQL);
    foreach ($result as $i){
        $pocet = htmlspecialchars($i["mnozstvi"]);
        $SQL = 'SELECT * FROM '.$_SESSION["jmeno"].' WHERE typ="potraviny";';
        $result = $db_conn->query($SQL);
        foreach ($result as $j){
            $ano = "ne";
            for($k=0;$k<count($blacklist);$k++){
                if($blacklist[$k]==htmlspecialchars($i["id"])){
                    $ano = "ano";
                }      
            }
            if(htmlspecialchars($i["jmeno"])==htmlspecialchars($j["jmeno"]) and htmlspecialchars($i["spotreba"])==htmlspecialchars($j["spotreba"]) and htmlspecialchars($i["kategorie"])==htmlspecialchars($j["kategorie"]) and htmlspecialchars($i["jednotky"])==htmlspecialchars($j["jednotky"]) and htmlspecialchars($i["id"])!= htmlspecialchars($j["id"]) and $ano == "ne"){
                $pocet = $pocet+htmlspecialchars($j["mnozstvi"]);
                $SQL = "DELETE FROM ".$_SESSION["jmeno"]." WHERE id='".htmlspecialchars($j["id"])."';";
                $result = $db_conn->query($SQL);
                array_push($blacklist, htmlspecialchars($j["id"]));
            }
        }
        $SQL = "UPDATE ".$_SESSION['jmeno']." SET mnozstvi='".$pocet."' WHERE id=".htmlspecialchars($i["id"]).";";
        $result = $db_conn->query($SQL);
    }
}
function kategorie($db_conn,$kategorie){
    $SQL = 'SELECT * FROM '.$_SESSION["jmeno"].' WHERE typ="kategorie" AND jmeno="'.$kategorie.'";';
    $result = $db_conn->query($SQL);
    foreach ($result as $i){
        return '<img src="'. htmlspecialchars($i["poznamky"]).'" class="ikonka">';
    }
    
    return '<div class="prazdne"></div><div class="ikonka" style="left:0px;width:120px;text-align:center;"><br>'.$kategorie.'</div>';
}
 function kategorie2($kategorie){
     $db_conn = connect_db();
    $SQL = 'SELECT * FROM '.$_SESSION["jmeno"].' WHERE typ="kategorie" AND jmeno="'.$kategorie.'";';
    $result = $db_conn->query($SQL);
    foreach ($result as $i){
        return '<img src="'. htmlspecialchars($i["poznamky"]).'" class="ikonka">';
    }
    
    return '<div class="prazdne"></div><div class="ikonka" style="left:0px;width:120px;text-align:center;"><br>'.$kategorie.'</div>';
}
?>
