<?php
include_once 'db.php';
include 'funkce.php';
include 'potravina.php';

if (isset($_GET['jmeno'])) {
    $SQL = 'SELECT * FROM uzivatele WHERE jmeno="' . $_GET['jmeno'] . '";';
    $result = $db_conn->query($SQL);
    if ($result !== NULL) {
        foreach ($result as $i) {
            if ($_GET['heslo'] == ($i["heslo"])) {
                $_SESSION["jmeno"] = $_GET['jmeno'];
            }
        }
    }
} else {
    if (!isset($_SESSION["jmeno"])) {
        if (isset($_COOKIE["jmeno"])) {
            $SQL = 'SELECT * FROM uzivatele WHERE jmeno="' . $_COOKIE['jmeno'] . '";';
            $result = $db_conn->query($SQL);
            if ($result !== NULL) {
                foreach ($result as $i) {
                    if ($_COOKIE["heslo"] == ($i["heslo"])) {
                        $_SESSION["jmeno"] = $_COOKIE["jmeno"];
                        $_SESSION["heslo"] = $_COOKIE["heslo"];
                    }
                }
            }
        }
        if (!isset($_SESSION["jmeno"])) {
            header("Location: uvod/index.html");
            die();
        }
    }
}


if (isset($_GET["mode"])) {
    $_SESSION["mode"] = $_GET["mode"];
}
if (!isset($_SESSION["mode"])) {
    $_SESSION["mode"] = "zakladni";
}
$mode = $_SESSION["mode"];


sloucit($db_conn);

$SQL = 'SELECT * FROM uzivatele WHERE jmeno="' . $_SESSION['jmeno'] . '";';
$result = $db_conn->query($SQL);
foreach ($result as $i) {
    if (htmlspecialchars($i["autozalohovani"]) == 1) {
        if (is_dir("zalohy" . $_SESSION['jmeno']) == FALSE) {
            mkdir("zalohy" . $_SESSION['jmeno'], 0700);
        }
        $zalohy = scandir("zalohy" . $_SESSION['jmeno']);
        for ($i = 2; $i < count($zalohy); $i++) {
            if (strpos($zalohy[$i], date("j.n.Y")) !== FALSE) {
                $dneshotovo = 0;
            }
        }
        if (!isset($dneshotovo)) {
            $obsah = "";
            $SQL = 'SELECT * FROM ' . $_SESSION["jmeno"] . ' WHERE typ="potraviny";';
            $result = $db_conn->query($SQL);
            foreach ($result as $i) {
                if ($obsah == "") {
                    $obsah = htmlspecialchars($i["ean"]) . "}" . htmlspecialchars($i["jmeno"]) . "}" . htmlspecialchars($i["kategorie"]) . "}" . htmlspecialchars($i["spotreba"]) . "}" . htmlspecialchars($i["mnozstvi"]) . "}" . htmlspecialchars($i["jednotky"]);
                } else {
                    $obsah = $obsah . "{" . htmlspecialchars($i["ean"]) . "}" . htmlspecialchars($i["jmeno"]) . "}" . htmlspecialchars($i["kategorie"]) . "}" . htmlspecialchars($i["spotreba"]) . "}" . htmlspecialchars($i["mnozstvi"]) . "}" . htmlspecialchars($i["jednotky"]);
                }
            }
            $myfile = fopen("zalohy" . $_SESSION['jmeno'] . "/" . date("j.n.Y G;i") . ".zaloha", "w") or die("Unable to open file!");
            $txt = $obsah;
            fwrite($myfile, $txt);
            fclose($myfile);
        }
    }
}
?>
<!DOCTYPE html>

<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/w3.css">
        <link rel="stylesheet" href="css/potraviny.css">
        <meta charset="UTF-8">
        <title></title>
        <style>
            .nadpis{
                top: 0px;
                position: relative;
                left: 200px;
            }
            .vyfotit{
                position: relative;
                width: 48px;
                height: 48px;
                cursor: pointer;
                top: -69px;
                left: 940px;
                background-image: url("ikonky/camera.png");
                background-size: 35px;
                background-repeat: no-repeat;
                background-position-y: 8px;
            }
            .skenovani{
                position: fixed;
                width: 600px;
                height: 550px;
                background-color: #4B8F8C;
                left: calc(50% - 300px);
                top: 100px;
            }
            #skener{
                display: none;
            }
            .ctecka{
                position: relative;
                top: 50px;
                left: 50px;
            }
        </style>
    </head>
    <body style="background-color:#cccccc;">

        <div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="mySidebar">
            <button class="w3-bar-item w3-button w3-large"
                    onclick="w3_close()">Zavřít &times;</button>
            <center><div class="prihlasovani" ></div><p><?php echo $_SESSION["jmeno"]; ?></p><a class="odhlasit" href="logout.php">odhlásit se</a><br></center>
            <a href="index.php?mode=zakladni" class="w3-bar-item w3-button">Domů</a>
            <center><p>Filtrovat</p> </center>  <hr /> 
            <a href="index.php?mode=jmeno" class="w3-bar-item w3-button">Podle názvu</a>
            <a href="index.php?mode=kategorie" class="w3-bar-item w3-button">podle kategorie</a>
            <a href="hledatdatum.php" class="w3-bar-item w3-button">datum spotřeby</a>

            <center><p>Správa dat</p> </center>  <hr /> 
            <a href="zalohovani.php" class="w3-bar-item w3-button">Zálohování</a>
            <a href="import.php" class="w3-bar-item w3-button">Import</a>
            <a href="export.php" class="w3-bar-item w3-button">Export</a>

            <center><p>Správa databáze</p> </center>  <hr /> 
            <a href="ulozenepotraviny.php" class="w3-bar-item w3-button">Uložené potraviny</a>
            <a href="stalepotraviny.php" class="w3-bar-item w3-button">Stálé potraviny</a>
            <a href="nastaveni.php" class="w3-bar-item w3-button">nastavení</a>
        </div>

        <div id="main" >

            <div class="w3-teal" > 
                <button id="openNav" class="w3-button w3-teal w3-xlarge" onclick="w3_open()">&#9776;</button>
                <div class="w3-container"><h1 class="nadpis">Skladové hospodářství</h1></div>
            </div>  

            <form method="post" action="index.php?mode=<?php
            if ($mode != "eam") {
                echo $mode;
            } else {
                echo 'ean';
            }
            ?>" id="formHledatEan">

                <?php
                if ($mode == "jmeno") {
                    if(!isset($_POST["jmeno"])){
                        $_POST["jmeno"] = "";
                    }
                    $hledaneJmeno = $_POST["jmeno"];
                    echo '<input type="text" name="jmeno" text="'.$hledaneJmeno.'" class="input" id="vyhledatpodleeanu" placeholder="Vyhledet podle jména" autofocus>';
                } else if ($mode == "kategorie") {
                    echo '<select class="input" id="vyhledatpodleeanu" name="kategorie">';
                    if (isset($_POST['kategorie'])) {
                        $kategorie = $_POST['kategorie'];
                        if ($kategorie == "") {
                            $SQL = 'SELECT * FROM ' . $_SESSION['jmeno'] . ' WHERE typ="kategorie" ORDER BY jmeno;';
                            $result = $db_conn->query($SQL);
                            foreach ($result as $i) {
                                if (!isset($kategorie)) {
                                    $kategorie = htmlspecialchars($i["jmeno"]);
                                }
                                echo "<option>" . htmlspecialchars($i["jmeno"]) . "</option>";
                            }
                        } else {
                            echo "<option>" . $kategorie . "</option>";
                            $SQL = 'SELECT * FROM ' . $_SESSION['jmeno'] . ' WHERE typ="kategorie" ORDER BY jmeno;';
                            $result = $db_conn->query($SQL);
                            foreach ($result as $i) {
                                if ($kategorie !== htmlspecialchars($i["jmeno"])) {
                                    echo "<option>" . htmlspecialchars($i["jmeno"]) . "</option>";
                                }
                            }
                        }
                    } else {
                        $SQL = 'SELECT * FROM ' . $_SESSION['jmeno'] . ' WHERE typ="kategorie" ORDER BY jmeno;';
                        $result = $db_conn->query($SQL);
                        foreach ($result as $i) {
                            if ($kategorie !== htmlspecialchars($i["jmeno"])) {
                                echo "<option>" . htmlspecialchars($i["jmeno"]) . "</option>";
                            }
                        }
                    }
                    echo '</select>';
                } else {
                    echo '<input type="text" name="ean" class="input" id="vyhledatpodleeanu" placeholder="Vyhledet podle eanu" autofocus>';
                    echo '<a  onclick="otevriKameru();" class="vyfotit"></a>';
                }
                ?>
                <input type="submit" class="listatlacitko" value=" "></form>
            <div class="seznam">
                <div  class="potravina"><a href="ean.php" class="pridatsean"></a><a href="vygenerovatEan.php" class="pridatbezean"></a></div>
                <?php
                $SQL = 'SELECT * FROM ' . $_SESSION["jmeno"] . ' WHERE typ="potraviny" ORDER BY jmeno;';
                $chyba = "Zatím zde nemáte žádné potraviny.";
                if ($mode == "zakladni") {
                    $SQL = 'SELECT * FROM ' . $_SESSION["jmeno"] . ' WHERE typ="potraviny" ORDER BY jmeno;';
                    $chyba = "Zatím zde nemáte žádné potraviny.";
                }
                if ($mode == "ean") {
                    if (isset($_POST["ean"])) {
                        $SQL = 'SELECT * FROM ' . $_SESSION["jmeno"] . ' WHERE typ="potraviny" AND ean="' . $_POST["ean"] . '";';
                        $chyba = "S kódem: " . $_POST["ean"] . " nebylo nic nalezeno.";
                    }
                }
                if ($mode == "kategorie") {
                    if (isset($_POST["kategorie"])) {
                        $SQL = 'SELECT * FROM ' . $_SESSION["jmeno"] . ' WHERE typ="potraviny" AND kategorie="' . $_POST["kategorie"] . '";';
                        $chyba = "V kategorii " . $_POST["kategorie"] . " zatím nic není.";
                    }
                }
                $result = $db_conn->query($SQL);
                foreach ($result as $i) {
                    if ($mode == "jmeno" and strlen($hledaneJmeno)>0 and strpos(htmlspecialchars($i['jmeno']), $hledaneJmeno) == false) {
                        continue;
                    }
                    $potravina = new Potravina(htmlspecialchars($i["id"]), htmlspecialchars($i["jmeno"]), htmlspecialchars($i["kategorie"]), htmlspecialchars($i["spotreba"]), htmlspecialchars($i["mnozstvi"]), htmlspecialchars($i["jednotky"]));
                    echo $potravina->htmlPotravina();
                    $necoNalezeno = 0;
                }
                if (!isset($necoNalezeno)) {
                    echo $chyba;
                }
                ?>

            </div>

        </div>
        <div class="uprava" id="uprava"><h3 class="upravaNadpis">Upravit</h3><div class="krizek" onclick="zavritupravovani()"></div><iframe id="iframe"src=""></iframe></div>
        <script type="text/javascript">
            document.getElementById("uprava").style.display = 'none';
            function upravit(id) {
                document.getElementById("iframe").src = 'upravit.php?id=' + id;
                document.getElementById("uprava").style.display = 'inline-block';
            }
            function zavritupravovani() {
                document.getElementById("uprava").style.display = 'none';
            }
            window.addEventListener("message", receiveMessage, false);
            function receiveMessage(event) {
                if (event.data === "zavrit") {
                    document.getElementById("uprava").style.display = 'none';
                    location.reload();
                } else {
                    document.getElementById("vyhledatpodleeanu").value = event.data;
                    document.getElementById("formHledatEan").submit();
                    document.getElementById("skener").style.display = 'none';
                    document.getElementById("frame").remove();
                }

                return;
            }
            function otevriKameru() {
                if (document.getElementById("skener").style.display == "none") {
                    var element = document.getElementById("skener");
                    document.getElementById("skener").style.display = 'inline-block';
                    var node = document.createElement("iframe");
                    node.setAttribute("src", "skener.php");
                    node.setAttribute("id", "frame");
                    document.getElementById("skener").appendChild(node);
                    // If you want to prefer back camera <iframe id="nacitac" class="ctecka" src="skener.php"></iframe>
                } else {
                    document.getElementById("skener").style.display = 'none';
                    document.getElementById("frame").remove();
                }
            }
            window.onload = function (e) {
                document.getElementById("skener").style.display = 'none';
            }

        </script>


        <?php
        if (isset($_GET['smazane'])) {
            echo '<center><a href="vratitPotravinu.php?vracenapotravina=' . $_GET['smazane'] . '" id="vratit" class="vratit" onclick="zmiz();">Vrátit smazanou potravinu</a></center>';
        }
        ?>      <div id="skener" class="skenovani">

        </div>
        <script src="jquery-3.3.1.min.js"></script>
        <script src="menu.js"></script>

    </body>
</html>
