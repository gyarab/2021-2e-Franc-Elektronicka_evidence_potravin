<?php 
include_once 'db.php';
if(!isset($_SESSION["jmeno"])){
    header("Location: uvod/index.html");
    die();
}

?><!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/w3.css">
        <meta charset="UTF-8">
        <title></title>
        <script type="text/javascript" src="./charts/loader.js"></script>
    <script type="text/javascript">

      // Load the Visualization API and the corechart package.
      google.charts.load('current', {'packages':['corechart']});

      // Set a callback to run when the Google Visualization API is loaded.
      google.charts.setOnLoadCallback(drawChart);

      // Callback that creates and populates a data table,
      // instantiates the pie chart, passes in the data and
      // draws it.
      function drawChart() {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Topping');
        data.addColumn('number', 'Slices');
        data.addRows([
          ['Mushrooms', 3],
          ['Onions', 1],
          ['Olives', 1],
          ['Zucchini', 1],
          ['Pepperoni', 2]
        ]);

        // Set chart options
        var options = {'title':'How Much Pizza I Ate Last Night'};

        // Instantiate and draw our chart, passing in some options.
        var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
    </script>
        
        
        <style>
            
            .nadpis{
                top: 0px;
                position: relative;
                left: 200px;
            }
            .input{
                position: relative;
                top: -70px; 
                border: none;
                border-radius: 4px;
            }
            .listatlacitko{
                position: relative;
                top: -70px;
                border: none;
                border-radius: 4px;
                height: 50px;
                width: 60px;
                left: 540px;
                background-image: url("lupa.png");
                background-size: 50px;
                background-position-x: 5px;
            }
            #vyhledatpodleeanu{
                margin: 0px;
                width: 400px;
                height: 50px;
                left: 600px;
            }
            p{
                font-family: arial;
                font-size: 20px;
            }
            .seznam{
    position: relative;
    text-align: center;
    top: 20px;
    left: 2px;
    overflow: auto;
}
            

.potravina{
    position: relative;
    display: block;
    width: 160px;
    height: 196px;
    margin: 2.5px;
    background-color: #999999;
}
.potravinatext{
    top: 10px;
    position: relative;
    font-family: arial;
    font-size: 15px;
    text-align: center;
    text-decoration: none;
    margin: 0px;
    width: 120px;
    height: 40px;
}
a{
     position: relative;
    text-decoration: none;
    margin: 0px;
    float: left;
}
.krizek{
    position: absolute;
    
                top: 2.5px;
                right: 2.5px;
                background-image: url("krizek.png");
                background-size: 15px;
                width: 15px;
                height: 15px;
                background-color: transparent;
                
            }
            .vratit{
                position: absolute;
                top: 0px;
                right: 0px;
                width: 500px;
                height: 50px;
                background: #cccccc;
                animation: priletnuti 1s ;
                transition: right 1s;
            }
            @keyframes priletnuti {
    from {right: -600px;}
    to {right: 0px;}
    
}
.pridatsean{
        position: relative;
        width: 70px;
        height: 70px;
        left: 25px;
        top: 10px;
        background-image: url("scanner.png");
        background-size: 70px;
        
    }
    .pridatbezean{
        position: relative;
        width: 70px;
        height: 70px;
        left: 25px;
        top: 15px;
        background-image: url("vytvor ean.png");
        background-size: 70px;
        
    }
                @media only screen and (max-width: 1000px) {
                #vyhledatpodleeanu{
                    left: 10px;
                    height: 50px;
                    width: 80%;
                }
                .nadpis{
               left: 20px;
            }
                form{
                    height: 0px;
                    position: relative;
                }
                .listatlacitko{
                     left: 5px;
                     top: -70px;
                }
                
                .seznam{
    position: relative;
    top: 2px;
    left: 2px;
    overflow: auto;

}
.vratit{
                position: absolute;
                top: 0px;
                right: 0px;
                width: 70%;
                height: 50px;
                background: #cccccc;
                animation: priletnuti 1s ;
                transition: right 1s;
            }
}
.ikonka{
    position: relative;
    width: 70px;
    left: 28px;
    top: 10px;
}
.import{
    position: relative;
    top: 150px;
    
}
        </style>
    </head>
    <body style="background-color:#cccccc;">


<div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="mySidebar">
  <button class="w3-bar-item w3-button w3-large"
  onclick="w3_close()">Zavřít &times;</button>
            <a href="index.php" class="w3-bar-item w3-button">Domů</a>
            <center><p>Filtrovat</p> </center>  <hr /> 
      
   <a href="hledatjmeno.php" class="w3-bar-item w3-button">Podle názvu</a>
  <a href="hledatkategorii.php" class="w3-bar-item w3-button">podle kategorie</a>
  <a href="hledatdatum.php" class="w3-bar-item w3-button">datum spotřeby</a>
  
  <center><p>Správa dat</p> </center>  <hr /> 
  
  <a href="#" class="w3-bar-item w3-button">Zálohování</a>
  <a href="analithics.php" class="w3-bar-item w3-button">Analitika</a>
  <center><p>Správa databáze</p> </center>  <hr /> 
  
  <a href="#" class="w3-bar-item w3-button">stálé potraviny</a>
  <a href="#" class="w3-bar-item w3-button">nastavení</a>
  <a href="#" class="w3-bar-item w3-button">odhlásit se</a>
</div>

        <div id="main" >

<div class="w3-teal" >
     
  <button id="openNav" class="w3-button w3-teal w3-xlarge" onclick="w3_open()">&#9776;</button>
  <div class="w3-container">
      
      <h1 class="nadpis">Import</h1>
      
  </div>
  
</div>  <center><div class="import">

        <div id="chart_div"></div>
   
</div>
   </center>
</div>   
        
<script>
function w3_open() {
  document.getElementById("main").style.marginLeft = "25%";
  document.getElementById("mySidebar").style.width = "25%";
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("openNav").style.display = 'none';
}
function w3_close() {
  document.getElementById("main").style.marginLeft = "0%";
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("openNav").style.display = "inline-block";
}
</script>
<script src="jquery-3.3.1.min.js"></script>
<script type="text/javascript">
                setTimeout(function(){    
                 $('.vratit').animate({right: '-600px'},"slow");

                    alert("funguje to");
                }, 3000);
                
                
            
                </script>


</body>
    </body>
</html>
