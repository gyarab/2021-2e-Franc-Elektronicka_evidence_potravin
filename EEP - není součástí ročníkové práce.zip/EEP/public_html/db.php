<?php

session_start();


define('DB_HOST','localhost');
define('DB_NAME','id14303150_eep');
define('DB_USERNAME','root');
define('DB_PASSWORD','');



$db_conn = connect_db();

function connect_db() {
    try {
        $db_connection = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8' , DB_USERNAME,DB_PASSWORD,array(PDO::MYSQL_ATTR_INIT_COMMAND =>"SET NAMES 'utf8'"));
        $db_connection->exec("SET CHARSET utf8");
        
    } catch (Exception $ex) {
        echo 'Nepodařilo se připojit k databázi';
        die();
    }
    return $db_connection;
}